package com.example.genericsqlapi.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

public class DynamicQueryServiceTest {

    private DynamicQueryService dynamicQueryService;

    private NamedParameterJdbcTemplate jdbcTemplate;

    @BeforeEach
    public void setup() {
        jdbcTemplate = Mockito.mock(NamedParameterJdbcTemplate.class);
        dynamicQueryService = new DynamicQueryService(jdbcTemplate);
    }

    @Test
    public void testExecuteSelect() {
        String sql = "SELECT * FROM users WHERE id = :id";
        Map<String, Object> params = Map.of("id", 1);

        // Mock queryForList using anyMap() to remove ambiguity
        when(jdbcTemplate.queryForList(eq(sql), anyMap()))
                .thenReturn(List.of(Map.of("id", 1, "username", "user1")));

        List<Map<String, Object>> result = dynamicQueryService.executeSelect(sql, params);

        assertThat(result).isNotNull();
        assertThat(result).hasSize(1);
        assertThat(result.get(0)).containsEntry("username", "user1");

        verify(jdbcTemplate, times(1)).queryForList(anyString(), anyMap());
    }

    @Test
    public void testExecuteUpdate() {
        String sql = "UPDATE users SET username = :username WHERE id = :id";
        Map<String, Object> params = Map.of("username", "newuser", "id", 1);

        // Mock update using anyMap() to remove ambiguity
        when(jdbcTemplate.update(eq(sql), anyMap()))
                .thenReturn(1);

        int rows = dynamicQueryService.executeUpdate(sql, params);

        assertThat(rows).isEqualTo(1);
        verify(jdbcTemplate, times(1)).update(anyString(), anyMap());
    }
}