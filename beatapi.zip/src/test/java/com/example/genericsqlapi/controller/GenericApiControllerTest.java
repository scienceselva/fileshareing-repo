package com.example.genericsqlapi.controller;

import com.example.genericsqlapi.dto.ApiConfig;
import com.example.genericsqlapi.dto.EndpointConfig;
import com.example.genericsqlapi.service.DynamicQueryService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.mockito.Mockito.when;

@WebMvcTest(controllers = GenericApiController.class)
public class GenericApiControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private DynamicQueryService dynamicQueryService;

    private ObjectMapper mapper = new ObjectMapper();

    private ApiConfig apiConfig;

    @BeforeEach
    public void setup() throws Exception {
        // Mock config with one endpoint
        EndpointConfig endpoint = new EndpointConfig();
        endpoint.setName("createUser");
        endpoint.setPath("/users");
        endpoint.setMethod("POST");
        endpoint.setSql("INSERT INTO users (username, email) VALUES (:username, :email)");
        endpoint.setInput(Map.of("username", "String", "email", "String"));
        endpoint.setOutput(Map.of("success", "Boolean", "message", "String"));

        apiConfig = new ApiConfig();
        apiConfig.setEndpoints(List.of(endpoint));
    }

    @Test
    public void testCreateUserSuccess() throws Exception {
        when(dynamicQueryService.executeUpdate(any(), any())).thenReturn(1);

        String jsonRequest = "{\n" +
                            "  \"username\": \"testuser\",\n" +
                            "  \"email\": \"test@example.com\"\n" +
                            "}";

        mockMvc.perform(post("/api/users")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRequest))
                .andExpect(status().isOk());
    }

    @Test
    public void testCreateUserMissingParam() throws Exception {
        String jsonRequest = "{\n" +
                            "  \"username\": \"testuser\"\n" +
                            "}";

        mockMvc.perform(post("/api/users")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRequest))
                .andExpect(status().isBadRequest());
    }
}