package com.example.genericsqlapi.dto;

import java.util.List;

/**
 * Represents the entire API configuration loaded from JSON.
 */
public class ApiConfig {
    private List<EndpointConfig> endpoints;

    public List<EndpointConfig> getEndpoints() {
        return endpoints;
    }

    public void setEndpoints(List<EndpointConfig> endpoints) {
        this.endpoints = endpoints;
    }
}