package com.example.genericsqlapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main Spring Boot Application class.
 */
@SpringBootApplication
public class GenericSqlApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(GenericSqlApiApplication.class, args);
    }
}