package com.example.genericsqlapi.controller;

import com.example.genericsqlapi.dto.ApiConfig;
import com.example.genericsqlapi.dto.EndpointConfig;
import com.example.genericsqlapi.service.DynamicQueryService;
import com.example.genericsqlapi.util.JsonUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.*;

/**
 * Controller that exposes generic endpoints as configured in JSON.
 */
@RestController
@RequestMapping("/api")
@Tag(name = "Generic SQL API", description = "Dynamically configured SQL API endpoints")
public class GenericApiController {

    private static final Logger logger = LogManager.getLogger(GenericApiController.class);

    private final DynamicQueryService dynamicQueryService;

    private ApiConfig apiConfig;

    public GenericApiController(DynamicQueryService dynamicQueryService) {
        this.dynamicQueryService = dynamicQueryService;
    }

    /**
     * Loads the JSON config on startup.
     */
    @PostConstruct
    public void loadConfig() throws IOException {
        this.apiConfig = JsonUtil.loadApiConfig("api-config.json");
        logger.info("Loaded API config with {} endpoints", apiConfig.getEndpoints().size());
    }

    /**
     * Generic handler for all configured endpoints.
     *
     * @param request HttpServletRequest to get path and method
     * @param params  Request parameters or body as Map
     * @return ResponseEntity with query result or error
     */
    @Operation(summary = "Generic dynamic endpoint")
    @RequestMapping(value = "/**", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE})
    public ResponseEntity<?> handleRequest(HttpServletRequest request, @RequestBody(required = false) Map<String, Object> params) {
        String requestPath = request.getRequestURI().substring(request.getContextPath().length() + "/api".length());
        String httpMethod = request.getMethod().toUpperCase();

        logger.debug("Received request: {} {}", httpMethod, requestPath);

        Optional<EndpointConfig> matchedEndpoint = apiConfig.getEndpoints().stream()
                .filter(e -> e.getPath().equalsIgnoreCase(requestPath) && e.getMethod().equalsIgnoreCase(httpMethod))
                .findFirst();

        if (matchedEndpoint.isEmpty()) {
            logger.warn("No endpoint config matched for path: {} and method: {}", requestPath, httpMethod);
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "Endpoint not found"));
        }

        EndpointConfig endpoint = matchedEndpoint.get();

        // Validate input params
        Map<String, Object> inputParams = params != null ? params : Collections.emptyMap();
        List<String> missingParams = new ArrayList<>();
        for (String requiredParam : endpoint.getInput().keySet()) {
            if (!inputParams.containsKey(requiredParam) || inputParams.get(requiredParam) == null) {
                missingParams.add(requiredParam);
            }
        }
        if (!missingParams.isEmpty()) {
            logger.warn("Missing required parameters: {}", missingParams);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "Missing required parameters", "missing", missingParams));
        }

        try {
            if ("GET".equalsIgnoreCase(httpMethod)) {
                List<Map<String, Object>> results = dynamicQueryService.executeSelect(endpoint.getSql(), inputParams);
                return ResponseEntity.ok(results);
            } else if ("POST".equalsIgnoreCase(httpMethod) || "PUT".equalsIgnoreCase(httpMethod) || "DELETE".equalsIgnoreCase(httpMethod)) {
                int rowsAffected = dynamicQueryService.executeUpdate(endpoint.getSql(), inputParams);
                Map<String, Object> response = new HashMap<>();
                response.put("success", rowsAffected > 0);
                response.put("rowsAffected", rowsAffected);
                return ResponseEntity.ok(response);
            } else {
                logger.warn("Unsupported HTTP method: {}", httpMethod);
                return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED)
                        .body(Map.of("error", "Unsupported HTTP method"));
            }
        } catch (Exception ex) {
            logger.error("Error executing SQL for endpoint {}: {}", endpoint.getName(), ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Internal server error", "details", ex.getMessage()));
        }
    }
}