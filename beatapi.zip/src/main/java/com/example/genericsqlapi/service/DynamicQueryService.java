package com.example.genericsqlapi.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Service to execute dynamic SQL queries with named parameters.
 */
@Service
public class DynamicQueryService {

    private static final Logger logger = LogManager.getLogger(DynamicQueryService.class);

    private final NamedParameterJdbcTemplate jdbcTemplate;

    public DynamicQueryService(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * Executes a SELECT query and returns the result list.
     *
     * @param sql         SQL statement with named parameters
     * @param inputParams Map of input parameter values
     * @return List of result maps
     */
    public List<Map<String, Object>> executeSelect(String sql, Map<String, Object> inputParams) {
        logger.debug("Executing SELECT SQL: {} with params {}", sql, inputParams);
        return jdbcTemplate.queryForList(sql, new MapSqlParameterSource(inputParams));
    }

    /**
     * Executes an INSERT/UPDATE/DELETE query and returns affected row count.
     *
     * @param sql         SQL statement with named parameters
     * @param inputParams Map of input parameter values
     * @return number of affected rows
     */
    public int executeUpdate(String sql, Map<String, Object> inputParams) {
        logger.debug("Executing UPDATE SQL: {} with params {}", sql, inputParams);
        return jdbcTemplate.update(sql, new MapSqlParameterSource(inputParams));
    }
}