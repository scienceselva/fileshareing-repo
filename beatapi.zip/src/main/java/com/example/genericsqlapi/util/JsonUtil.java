package com.example.genericsqlapi.util;

import com.example.genericsqlapi.dto.ApiConfig;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;

/**
 * Utility to load and parse JSON config files.
 */
public class JsonUtil {
    private static final ObjectMapper mapper = new ObjectMapper();

    public static ApiConfig loadApiConfig(String resourcePath) throws IOException {
        ClassPathResource resource = new ClassPathResource(resourcePath);
        return mapper.readValue(resource.getInputStream(), ApiConfig.class);
    }
}