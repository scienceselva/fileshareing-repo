# Generic SQL API - Spring Boot

## Overview

This project is a generic Spring Boot REST API that can connect to any SQL database by changing the connection string in `application.yml`. The API dynamically exposes endpoints configured in a JSON file (`api-config.json`) where you can define:

- Endpoint path and HTTP method
- SQL query to execute
- Input parameters and their types
- Output fields and their types

## Features

- Dynamic endpoints configured via JSON
- SQL execution using named parameters
- Generic input/output mapping
- Error handling with ControllerAdvice
- Logging with Log4j2 supporting multiple levels and debug mode
- Swagger UI integration at `/swagger-ui.html`
- Unit tests for controller and service layers
- Maven build with GitLab CI pipeline for AWS deployment

## Setup

1. Clone the repo.
2. Modify `application.yml` for your database connection.
3. Configure endpoints in `src/main/resources/api-config.json`.
4. Build the project: