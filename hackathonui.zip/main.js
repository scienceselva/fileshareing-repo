let endpoints = [];
let currentEndpointIndex = null;

const sampleEndpoints = [
  {
    name: 'getUsers',
    path: '/api/users',
    method: 'GET',
    sql: 'SELECT id, username, email, basicpay, advancepay FROM users WHERE id = :id',
    input: {
      id: { type: 'Integer', required: true }
    },
    output: {
      id: 'Integer',
      uname: 'String',
      mail: 'String',
      tpay: 'Integer'
    },
    outputfieldmapping: {
      id: 'id',
      uname: 'username',
      mail: 'email'
    },
    processing: {
      tpay: 'ADD (basicpay + advancepay)'
    }
  },
  {
    name: 'createUser',
    path: '/users',
    method: 'POST',
    sql: 'INSERT INTO users (username, email) VALUES (:username, :email)',
    input: {
      username: { type: 'String', required: true },
      email: { type: 'String', required: true }
    },
    output: {
      success: 'Boolean',
      message: 'String'
    },
    outputfieldmapping: {},
    processing: {}
  }
];

endpoints = [...sampleEndpoints];

function renderEndpointList() {
  const listContainer = document.getElementById('endpointList');
  listContainer.innerHTML = '';

  endpoints.forEach((endpoint, index) => {
    const item = document.createElement('div');
    item.className = `endpoint-item ${currentEndpointIndex === index ? 'active' : ''}`;
    item.innerHTML = `
      <div class="endpoint-item-name">${endpoint.name}</div>
      <div class="endpoint-item-details">
        <span class="endpoint-item-method">${endpoint.method}</span>
        <span>${endpoint.path}</span>
      </div>
    `;
    item.addEventListener('click', () => selectEndpoint(index));
    listContainer.appendChild(item);
  });
}

function selectEndpoint(index) {
  currentEndpointIndex = index;
  renderEndpointList();
  loadEndpointIntoForm(endpoints[index]);
  document.getElementById('emptyState').style.display = 'none';
  document.getElementById('editorForm').style.display = 'block';
  document.getElementById('deleteBtn').style.display = 'block';
}

function loadEndpointIntoForm(endpoint) {
  document.getElementById('endpointName').value = endpoint.name;
  document.getElementById('endpointPath').value = endpoint.path;
  document.getElementById('endpointMethod').value = endpoint.method;
  document.getElementById('endpointSql').value = endpoint.sql;

  const inputContainer = document.getElementById('inputFields');
  inputContainer.innerHTML = '';
  Object.entries(endpoint.input || {}).forEach(([key, value]) => {
    const type = typeof value === 'object' ? value.type : value;
    const required = typeof value === 'object' ? value.required : false;
    addInputField(key, type, required);
  });

  const outputContainer = document.getElementById('outputFields');
  outputContainer.innerHTML = '';
  Object.entries(endpoint.output || {}).forEach(([key, value]) => {
    addOutputField(key, value);
  });

  const mappingContainer = document.getElementById('mappingFields');
  mappingContainer.innerHTML = '';
  Object.entries(endpoint.outputfieldmapping || {}).forEach(([key, value]) => {
    addMappingField(key, value);
  });

  const processingContainer = document.getElementById('processingFields');
  processingContainer.innerHTML = '';
  Object.entries(endpoint.processing || {}).forEach(([key, value]) => {
    addProcessingField(key, value);
  });
}

function addInputField(name = '', type = 'String', required = false) {
  const container = document.getElementById('inputFields');
  const row = document.createElement('div');
  row.className = 'field-row';
  row.innerHTML = `
    <div class="form-group">
      <label>Parameter Name</label>
      <input type="text" class="input-name" value="${name}" placeholder="e.g., id" />
    </div>
    <div class="form-group">
      <label>Type</label>
      <select class="input-type">
        <option value="String" ${type === 'String' ? 'selected' : ''}>String</option>
        <option value="Integer" ${type === 'Integer' ? 'selected' : ''}>Integer</option>
        <option value="Boolean" ${type === 'Boolean' ? 'selected' : ''}>Boolean</option>
        <option value="Float" ${type === 'Float' ? 'selected' : ''}>Float</option>
        <option value="Date" ${type === 'Date' ? 'selected' : ''}>Date</option>
      </select>
      <div class="checkbox-group">
        <input type="checkbox" class="input-required" ${required ? 'checked' : ''} />
        <label>Required</label>
      </div>
    </div>
    <button type="button" class="btn-remove" onclick="this.parentElement.remove()">×</button>
  `;
  container.appendChild(row);
}

function addOutputField(name = '', type = 'String') {
  const container = document.getElementById('outputFields');
  const row = document.createElement('div');
  row.className = 'field-row';
  row.innerHTML = `
    <div class="form-group">
      <label>Field Name</label>
      <input type="text" class="output-name" value="${name}" placeholder="e.g., id" />
    </div>
    <div class="form-group">
      <label>Type</label>
      <select class="output-type">
        <option value="String" ${type === 'String' ? 'selected' : ''}>String</option>
        <option value="Integer" ${type === 'Integer' ? 'selected' : ''}>Integer</option>
        <option value="Boolean" ${type === 'Boolean' ? 'selected' : ''}>Boolean</option>
        <option value="Float" ${type === 'Float' ? 'selected' : ''}>Float</option>
        <option value="Date" ${type === 'Date' ? 'selected' : ''}>Date</option>
      </select>
    </div>
    <button type="button" class="btn-remove" onclick="this.parentElement.remove()">×</button>
  `;
  container.appendChild(row);
}

function addMappingField(outputField = '', dbField = '') {
  const container = document.getElementById('mappingFields');
  const row = document.createElement('div');
  row.className = 'field-row mapping-row';
  row.innerHTML = `
    <div class="form-group">
      <label>Output Field</label>
      <input type="text" class="mapping-output" value="${outputField}" placeholder="e.g., uname" />
    </div>
    <div class="form-group">
      <label>Database Field</label>
      <input type="text" class="mapping-db" value="${dbField}" placeholder="e.g., username" />
    </div>
    <button type="button" class="btn-remove" onclick="this.parentElement.remove()">×</button>
  `;
  container.appendChild(row);
}

function addProcessingField(field = '', expression = '') {
  const container = document.getElementById('processingFields');
  const row = document.createElement('div');
  row.className = 'field-row processing-row';
  row.innerHTML = `
    <div class="form-group">
      <label>Field Name</label>
      <input type="text" class="processing-field" value="${field}" placeholder="e.g., tpay" />
    </div>
    <div class="form-group">
      <label>Expression</label>
      <input type="text" class="processing-expr" value="${expression}" placeholder="e.g., ADD (basicpay + advancepay)" />
    </div>
    <button type="button" class="btn-remove" onclick="this.parentElement.remove()">×</button>
  `;
  container.appendChild(row);
}

function collectFormData() {
  const endpoint = {
    name: document.getElementById('endpointName').value,
    path: document.getElementById('endpointPath').value,
    method: document.getElementById('endpointMethod').value,
    sql: document.getElementById('endpointSql').value,
    input: {},
    output: {},
    outputfieldmapping: {},
    processing: {}
  };

  document.querySelectorAll('#inputFields .field-row').forEach(row => {
    const name = row.querySelector('.input-name').value;
    const type = row.querySelector('.input-type').value;
    const required = row.querySelector('.input-required').checked;
    if (name) {
      endpoint.input[name] = { type, required };
    }
  });

  document.querySelectorAll('#outputFields .field-row').forEach(row => {
    const name = row.querySelector('.output-name').value;
    const type = row.querySelector('.output-type').value;
    if (name) {
      endpoint.output[name] = type;
    }
  });

  document.querySelectorAll('#mappingFields .field-row').forEach(row => {
    const outputField = row.querySelector('.mapping-output').value;
    const dbField = row.querySelector('.mapping-db').value;
    if (outputField && dbField) {
      endpoint.outputfieldmapping[outputField] = dbField;
    }
  });

  document.querySelectorAll('#processingFields .field-row').forEach(row => {
    const field = row.querySelector('.processing-field').value;
    const expr = row.querySelector('.processing-expr').value;
    if (field && expr) {
      endpoint.processing[field] = expr;
    }
  });

  return endpoint;
}

function saveEndpoint() {
  const endpoint = collectFormData();

  if (!endpoint.name || !endpoint.path || !endpoint.method || !endpoint.sql) {
    alert('Please fill in all required fields (Name, Path, Method, SQL)');
    return;
  }

  if (currentEndpointIndex !== null) {
    endpoints[currentEndpointIndex] = endpoint;
  } else {
    endpoints.push(endpoint);
    currentEndpointIndex = endpoints.length - 1;
  }

  renderEndpointList();
  alert('Endpoint saved successfully!');
}

function deleteEndpoint() {
  if (currentEndpointIndex === null) return;

  if (confirm('Are you sure you want to delete this endpoint?')) {
    endpoints.splice(currentEndpointIndex, 1);
    currentEndpointIndex = null;
    document.getElementById('emptyState').style.display = 'flex';
    document.getElementById('editorForm').style.display = 'none';
    renderEndpointList();
  }
}

function createNewEndpoint() {
  currentEndpointIndex = null;
  document.getElementById('endpointForm').reset();
  document.getElementById('inputFields').innerHTML = '';
  document.getElementById('outputFields').innerHTML = '';
  document.getElementById('mappingFields').innerHTML = '';
  document.getElementById('processingFields').innerHTML = '';
  document.getElementById('emptyState').style.display = 'none';
  document.getElementById('editorForm').style.display = 'block';
  document.getElementById('deleteBtn').style.display = 'none';
  renderEndpointList();
}

function convertToYAML() {
  let yaml = 'endpoints:\n\n';

  endpoints.forEach(endpoint => {
    yaml += `  - name: ${endpoint.name}\n`;
    yaml += `    path: ${endpoint.path}\n`;
    yaml += `    method: ${endpoint.method}\n`;
    yaml += `    sql: ${endpoint.sql}\n`;

    if (Object.keys(endpoint.input).length > 0) {
      yaml += '    input:\n';
      Object.entries(endpoint.input).forEach(([key, value]) => {
        yaml += `      ${key}: ${value.type}\n`;
        if (value.required) {
          yaml += `      required: true\n`;
        }
      });
    }

    if (Object.keys(endpoint.output).length > 0) {
      yaml += '    output:\n';
      Object.entries(endpoint.output).forEach(([key, value]) => {
        yaml += `      ${key}: ${value}\n`;
      });
    }

    if (Object.keys(endpoint.outputfieldmapping).length > 0) {
      yaml += '    outputfieldmapping:\n';
      Object.entries(endpoint.outputfieldmapping).forEach(([key, value]) => {
        yaml += `      ${key}: ${value}\n`;
      });
    }

    if (Object.keys(endpoint.processing).length > 0) {
      yaml += '    processing:\n';
      Object.entries(endpoint.processing).forEach(([key, value]) => {
        yaml += `      ${key}: ${value}\n`;
      });
    }

    yaml += '\n';
  });

  return yaml;
}

function exportYAML() {
  const yaml = convertToYAML();
  document.getElementById('yamlOutput').value = yaml;
  document.getElementById('yamlModal').classList.add('active');
}

function importYAML() {
  document.getElementById('yamlInput').value = '';
  document.getElementById('importModal').classList.add('active');
}

function parseYAML() {
  const yamlText = document.getElementById('yamlInput').value;

  try {
    const lines = yamlText.split('\n');
    const parsedEndpoints = [];
    let currentEndpoint = null;
    let currentSection = null;

    lines.forEach(line => {
      const trimmed = line.trim();

      if (trimmed.startsWith('- name:')) {
        if (currentEndpoint) {
          parsedEndpoints.push(currentEndpoint);
        }
        currentEndpoint = {
          name: trimmed.split('name:')[1].trim(),
          input: {},
          output: {},
          outputfieldmapping: {},
          processing: {}
        };
        currentSection = null;
      } else if (currentEndpoint) {
        if (trimmed.startsWith('path:')) {
          currentEndpoint.path = trimmed.split('path:')[1].trim();
        } else if (trimmed.startsWith('method:')) {
          currentEndpoint.method = trimmed.split('method:')[1].trim();
        } else if (trimmed.startsWith('sql:')) {
          currentEndpoint.sql = trimmed.split('sql:')[1].trim();
        } else if (trimmed === 'input:') {
          currentSection = 'input';
        } else if (trimmed === 'output:') {
          currentSection = 'output';
        } else if (trimmed === 'outputfieldmapping:') {
          currentSection = 'outputfieldmapping';
        } else if (trimmed === 'processing:') {
          currentSection = 'processing';
        } else if (trimmed.startsWith('required:') && currentSection === 'input') {
          const lastKey = Object.keys(currentEndpoint.input).pop();
          if (lastKey) {
            const value = currentEndpoint.input[lastKey];
            currentEndpoint.input[lastKey] = {
              type: value,
              required: trimmed.includes('true')
            };
          }
        } else if (trimmed && trimmed.includes(':') && currentSection) {
          const parts = trimmed.split(':');
          const key = parts[0].trim();
          const value = parts.slice(1).join(':').trim();

          if (currentSection === 'input') {
            currentEndpoint.input[key] = value;
          } else if (currentSection === 'output') {
            currentEndpoint.output[key] = value;
          } else if (currentSection === 'outputfieldmapping') {
            currentEndpoint.outputfieldmapping[key] = value;
          } else if (currentSection === 'processing') {
            currentEndpoint.processing[key] = value;
          }
        }
      }
    });

    if (currentEndpoint) {
      parsedEndpoints.push(currentEndpoint);
    }

    endpoints = parsedEndpoints;
    renderEndpointList();
    document.getElementById('importModal').classList.remove('active');
    alert('YAML imported successfully!');
  } catch (error) {
    alert('Error parsing YAML: ' + error.message);
  }
}

function copyToClipboard() {
  const yamlText = document.getElementById('yamlOutput').value;
  navigator.clipboard.writeText(yamlText).then(() => {
    alert('YAML copied to clipboard!');
  });
}

document.getElementById('addNewBtn').addEventListener('click', createNewEndpoint);
document.getElementById('saveBtn').addEventListener('click', saveEndpoint);
document.getElementById('deleteBtn').addEventListener('click', deleteEndpoint);
document.getElementById('addInputBtn').addEventListener('click', () => addInputField());
document.getElementById('addOutputBtn').addEventListener('click', () => addOutputField());
document.getElementById('addMappingBtn').addEventListener('click', () => addMappingField());
document.getElementById('addProcessingBtn').addEventListener('click', () => addProcessingField());
document.getElementById('exportYamlBtn').addEventListener('click', exportYAML);
document.getElementById('importYamlBtn').addEventListener('click', importYAML);
document.getElementById('copyYamlBtn').addEventListener('click', copyToClipboard);
document.getElementById('parseYamlBtn').addEventListener('click', parseYAML);

document.querySelectorAll('.modal-close').forEach(btn => {
  btn.addEventListener('click', (e) => {
    e.target.closest('.modal').classList.remove('active');
  });
});

document.querySelectorAll('.modal').forEach(modal => {
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      modal.classList.remove('active');
    }
  });
});

renderEndpointList();
