const express = require('express');
const { exec } = require('child_process');
const app = express();
const cors = require('cors');
const path = require('path');
const port = 3000;

// CORS configuration
app.use(cors({
  origin: '*', // Allow all origins
  methods: ['GET', 'POST', 'OPTIONS', 'PUT', 'DELETE'], // Allowed HTTP methods
  allowedHeaders: ['Content-Type', 'Authorization'], // Allowed headers
  credentials: false // Don't allow credentials
}));

app.use(express.static(path.join(__dirname, 'public')));

// Middleware to parse JSON bodies
app.use(express.json());

// Security middleware to validate commands
const validateCommand = (req, res, next) => {
    const { command } = req.body;
    
    if (!command) {
        return res.status(400).json({ error: 'Command is required in the request body' });
    }
    
    // Basic security check - prevent potentially dangerous commands
    const dangerousPatterns = [
        'rm -rf',
        'mkfs',
        'dd',
        'shutdown',
        'reboot',
        'poweroff',
        ';', '&&', '||', // command chaining
        '>', '<', '|'    // redirection
    ];
    
    const isDangerous = dangerousPatterns.some(pattern => 
        command.toLowerCase().includes(pattern)
    );
    
    if (isDangerous) {
        return res.status(403).json({ 
            error: 'Potentially dangerous command detected',
            message: 'This command contains patterns that could harm the system'
        });
    }
    
    next();
};

// POST endpoint to execute commands
app.post('/execute', validateCommand, (req, res) => {
    const { command } = req.body;
    
    exec(command, { timeout: 5000 }, (error, stdout, stderr) => {
        if (error) {
            return res.status(400).json({
                error: 'Command execution failed',
                message: error.message,
                stderr: stderr
            });
        }
        
        res.json({
            command: command,
            output: stdout,
            error: stderr || null
        });
    });
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Something went wrong!' });
});

//app.options('*', cors(corsOptions));

app.listen(port, () => {
    console.log(`Command execution API running on http://localhost:${port}`);
});