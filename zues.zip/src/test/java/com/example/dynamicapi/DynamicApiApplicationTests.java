package com.example.dynamicapi;

import com.example.dynamicapi.config.ConfigLoader;
import com.example.dynamicapi.model.EndpointDefinition;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.*;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class DynamicApiApplicationTests {

    @Autowired
    private ConfigLoader configLoader;

    @Autowired
    private TestRestTemplate restTemplate;

    private static Path tempYamlFile;

    @BeforeEach
    void setup() throws Exception {
        if (tempYamlFile == null) {
            // Copy test YAML file from classpath to temp file for ConfigLoader
            File resource = new ClassPathResource("test_dynamic_api_endpoints.yaml").getFile();
            tempYamlFile = Files.createTempFile("dynamic_api_test", ".yaml");
            Files.writeString(tempYamlFile, Files.readString(resource.toPath()));
            System.setProperty("dynamicapi.yaml.path", tempYamlFile.toString());
        }
    }

    @Test
    void contextLoads() {
        List<EndpointDefinition> endpoints = configLoader.getEndpointDefinitions();
        assertThat(endpoints).isNotNull();
        assertThat(endpoints).isNotEmpty();
    }

    @Test
    void testDynamicEndpointResponse() {
        String url = "/api/test";

        HttpHeaders headers = new HttpHeaders();        

        HttpEntity<Void> entity = new HttpEntity<>(headers);

        ResponseEntity<List> response = restTemplate.exchange(url, HttpMethod.GET, entity, List.class);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody()).isNotEmpty();
    }

}
