package com.example.dynamicapi.validation;

import com.example.dynamicapi.model.InputField;
import com.example.dynamicapi.model.InputField.ValidationRules;
import org.junit.jupiter.api.Test;

import java.util.regex.Pattern;

import static org.assertj.core.api.Assertions.assertThatThrownBy;

public class InputValidationTests {

    @Test
    public void testStringValidationRegex() {
        InputField inputField = new InputField();
        inputField.setName("username");
        inputField.setType("string");
        inputField.setRequired(true);
        ValidationRules vr = new ValidationRules();
        vr.setRegex("^[a-zA-Z0-9]{3,10}$");
        inputField.setValidationRules(vr);

        // Valid input - no exception
        validateInput("user123", inputField);

        // Invalid input - expect exception
        assertThatThrownBy(() -> validateInput("user 123!", inputField))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("does not match regex");
    }

    @Test
    public void testIntegerValidationMinMax() {
        InputField inputField = new InputField();
        inputField.setName("age");
        inputField.setType("integer");
        ValidationRules vr = new ValidationRules();
        vr.setMin(18);
        vr.setMax(65);
        inputField.setValidationRules(vr);

        validateInput("30", inputField);

        assertThatThrownBy(() -> validateInput("10", inputField))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("must be >=");
        assertThatThrownBy(() -> validateInput("100", inputField))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("must be <=");
    }

    @Test
    public void testDateValidation() {
        InputField inputField = new InputField();
        inputField.setName("date");
        inputField.setType("date");

        validateInput("2023-01-01", inputField);

        assertThatThrownBy(() -> validateInput("01-01-2023", inputField))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("must be a date");
    }

    private void validateInput(String value, InputField field) {
        // We replicate the parseAndValidateInput logic from DynamicEndpointRegistrar
        String type = field.getType();
        if (type == null) {
            type = "string";
        }
        switch (type.toLowerCase()) {
            case "string" -> {
                if (field.getValidationRules() != null && field.getValidationRules().getRegex() != null) {
                    String regex = field.getValidationRules().getRegex();
                    if (!Pattern.matches(regex, value)) {
                        throw new IllegalArgumentException("Parameter '" + field.getName() + "' does not match regex pattern.");
                    }
                }
            }
            case "integer" -> {
                int intValue = Integer.parseInt(value);
                if (field.getValidationRules() != null) {
                    Integer min = field.getValidationRules().getMin();
                    Integer max = field.getValidationRules().getMax();
                    if (min != null && intValue < min) {
                        throw new IllegalArgumentException("Parameter '" + field.getName() + "' must be >= " + min);
                    }
                    if (max != null && intValue > max) {
                        throw new IllegalArgumentException("Parameter '" + field.getName() + "' must be <= " + max);
                    }
                }
            }
            case "date" -> {
                try {
                    java.sql.Date.valueOf(value);
                } catch (IllegalArgumentException ex) {
                    throw new IllegalArgumentException("Parameter '" + field.getName() + "' must be a date in yyyy-MM-dd format.");
                }
            }
            default -> {
                // no-op for tests
            }
        }
    }
}
