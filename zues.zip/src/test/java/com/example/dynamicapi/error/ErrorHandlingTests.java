package com.example.dynamicapi.error;

import com.example.dynamicapi.config.ConfigLoader;
import com.example.dynamicapi.model.EndpointDefinition;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class ErrorHandlingTests {

    @Autowired
    private TestRestTemplate restTemplate;

    @Autowired
    private ConfigLoader configLoader;

    @Test
    public void testMissingRequiredParameter() {
        List<EndpointDefinition> endpoints = configLoader.getEndpointDefinitions();
        assertThat(endpoints).isNotEmpty();

        EndpointDefinition endpoint = endpoints.get(0);
        String url = endpoint.getPath();

        HttpHeaders headers = new HttpHeaders();
        
        // Intentionally omit required parameters
        HttpEntity<Void> entity = new HttpEntity<>(headers);

        ResponseEntity<Map> response = restTemplate.exchange(url, HttpMethod.GET, entity, Map.class);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(response.getBody()).containsKey("error");
    }

    @Test
    public void testInvalidJwtToken() {
        String url = "/api/test";

        HttpHeaders headers = new HttpHeaders();        

        HttpEntity<Void> entity = new HttpEntity<>(headers);

        ResponseEntity<Map> response = restTemplate.exchange(url, HttpMethod.GET, entity, Map.class);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.FORBIDDEN);
    }

}
