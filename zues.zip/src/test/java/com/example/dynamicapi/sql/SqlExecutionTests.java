package com.example.dynamicapi.sql;

import com.example.dynamicapi.config.ConfigLoader;
import com.example.dynamicapi.model.EndpointDefinition;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
public class SqlExecutionTests {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private ConfigLoader configLoader;

    @Autowired
    private TestRestTemplate restTemplate;

    @BeforeEach
    void setupDb() {
        jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS test_table (id INT PRIMARY KEY, name VARCHAR(255));");
        jdbcTemplate.execute("DELETE FROM test_table;");
        jdbcTemplate.update("INSERT INTO test_table (id, name) VALUES (?, ?)", 1, "Alice");
        jdbcTemplate.update("INSERT INTO test_table (id, name) VALUES (?, ?)", 2, "Bob");
    }

    @Test
    void testSqlQueryExecution() {
        List<EndpointDefinition> endpoints = configLoader.getEndpointDefinitions();
        assertThat(endpoints).isNotEmpty();

        EndpointDefinition endpoint = endpoints.get(0);
        String url = endpoint.getPath() + "?id=1";

        var headers = new org.springframework.http.HttpHeaders();
        
        var entity = new org.springframework.http.HttpEntity<Void>(headers);

        var response = restTemplate.exchange(url, org.springframework.http.HttpMethod.GET, entity, List.class);

        assertThat(response.getStatusCode().is2xxSuccessful()).isTrue();
        assertThat(response.getBody()).isNotEmpty();
    }

}
