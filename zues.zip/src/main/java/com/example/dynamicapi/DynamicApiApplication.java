package com.example.dynamicapi;

import com.example.dynamicapi.config.ConfigLoader;
import com.example.dynamicapi.config.DynamicEndpointRegistrar;
//import com.example.dynamicapi.config.SecurityConfig;
import com.example.dynamicapi.config.SwaggerConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

@SpringBootApplication
@Import({ConfigLoader.class, DynamicEndpointRegistrar.class, SwaggerConfig.class})
public class DynamicApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(DynamicApiApplication.class, args);
    }
}
