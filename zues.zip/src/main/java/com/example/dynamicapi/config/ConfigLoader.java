package com.example.dynamicapi.config;

import com.example.dynamicapi.model.EndpointDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.yaml.snakeyaml.Yaml;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

@Service
public class ConfigLoader {

    private static final Logger logger = LoggerFactory.getLogger(ConfigLoader.class);

    private final String yamlFilePath;

    private List<EndpointDefinition> endpointDefinitions;

    public ConfigLoader(String yamlFilePath) {
        this.yamlFilePath = yamlFilePath;
        loadYaml();
    }

    @SuppressWarnings("unchecked")
    private void loadYaml() {
        if (yamlFilePath == null || yamlFilePath.isBlank()) {
            logger.error("YAML file path is not configured or empty.");
            throw new IllegalStateException("YAML file path is not configured.");
        }
        Path path = Path.of(yamlFilePath);
        if (!Files.exists(path)) {
            logger.error("YAML file does not exist at path: {}", yamlFilePath);
            throw new IllegalStateException("YAML file does not exist at path: " + yamlFilePath);
        }
        try (InputStream inputStream = new FileInputStream(yamlFilePath)) {
            Yaml yaml = new Yaml();
            Map<String, Object> root = yaml.load(inputStream);
            if (root == null || root.isEmpty()) {
                logger.warn("YAML file is empty or invalid.");
                throw new IllegalStateException("YAML file is empty or invalid.");
            }
            Object endpointsObj = root.get("endpoints");
            if (!(endpointsObj instanceof List<?> endpointsList)) {
                logger.error("YAML 'endpoints' key is missing or not a list.");
                throw new IllegalStateException("YAML 'endpoints' key is missing or not a list.");
            }
            endpointDefinitions = EndpointDefinition.fromList(endpointsList);
            logger.info("Loaded {} endpoint definitions from YAML file.", endpointDefinitions.size());
        } catch (IOException ex) {
            logger.error("Failed to read YAML file: {}", ex.getMessage());
            throw new IllegalStateException("Failed to read YAML file: " + ex.getMessage(), ex);
        }
    }

    public List<EndpointDefinition> getEndpointDefinitions() {
        return endpointDefinitions;
    }
}
