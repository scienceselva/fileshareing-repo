package com.example.dynamicapi.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.Operation;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.media.ArraySchema;
import io.swagger.v3.oas.models.media.Content;
import io.swagger.v3.oas.models.media.MediaType;
import io.swagger.v3.oas.models.media.ObjectSchema;
import io.swagger.v3.oas.models.media.Schema;
import io.swagger.v3.oas.models.responses.ApiResponse;
import io.swagger.v3.oas.models.responses.ApiResponses;
import io.swagger.v3.oas.models.servers.Server;
import org.springdoc.core.customizers.OpenApiCustomiser;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Dynamic Generic API")
                        .version("1.0")
                        .description("API dynamically generated from external YAML configuration"))
                .servers(List.of(new Server().url("/")));
    }

    /**
     * Customize OpenAPI to add dynamic endpoint documentation.
     * This example demonstrates adding a sample operation with response schema.
     * Replace or extend this logic to generate docs for your dynamic endpoints.
     */
    @Bean
    public OpenApiCustomiser dynamicEndpointsOpenApiCustomiser() {
        return openApi -> {
            // Example: Add a sample path with a GET operation
            openApi.getPaths().forEach((path, pathItem) -> {
                pathItem.readOperations().forEach(operation -> {
                    // For demonstration, add 200 response with schema
                    ApiResponses responses = operation.getResponses();
                    if (responses == null) {
                        responses = new ApiResponses();
                        operation.setResponses(responses);
                    }
                    if (!responses.containsKey("200")) {
                        ApiResponse response = new ApiResponse()
                                .description("Successful operation");

                        Schema<?> respSchema = new ArraySchema()
                                .items(new ObjectSchema());

                        Content content = new Content();
                        content.addMediaType("application/json", new MediaType().schema(respSchema));
                        response.setContent(content);
                        responses.addApiResponse("200", response);
                    }
                });
            });
        };
    }
}