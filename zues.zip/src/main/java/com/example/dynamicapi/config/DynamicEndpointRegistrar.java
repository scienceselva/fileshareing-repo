package com.example.dynamicapi.config;

import com.example.dynamicapi.model.EndpointDefinition;
import com.example.dynamicapi.model.InputField;
import com.example.dynamicapi.model.OutputFieldMapping;
import com.example.dynamicapi.model.QueryDefinition;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.framework.AopInfrastructureBean;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import java.lang.reflect.Method;
import java.sql.Date;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Component
public class DynamicEndpointRegistrar implements ApplicationContextAware, InitializingBean {

    private static final Logger logger = LoggerFactory.getLogger(DynamicEndpointRegistrar.class);

    private ApplicationContext applicationContext;

    private final ConfigLoader configLoader;

    private final JdbcTemplate jdbcTemplate;

    private final RequestMappingHandlerMapping handlerMapping;

    public DynamicEndpointRegistrar(ConfigLoader configLoader, JdbcTemplate jdbcTemplate, RequestMappingHandlerMapping handlerMapping) {
        this.configLoader = configLoader;
        this.jdbcTemplate = jdbcTemplate;
        this.handlerMapping = handlerMapping;
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        List<EndpointDefinition> endpoints = configLoader.getEndpointDefinitions();
        if (endpoints == null || endpoints.isEmpty()) {
            logger.warn("No endpoint definitions found to register.");
            return;
        }
        for (EndpointDefinition endpoint : endpoints) {
            registerEndpoint(endpoint);
        }
        logger.info("Completed registering {} dynamic endpoints.", endpoints.size());
    }

    private void registerEndpoint(EndpointDefinition endpoint) throws NoSuchMethodException {
        String path = endpoint.getPath();
        List<String> methods = endpoint.getMethods();
        if (path == null || path.isBlank()) {
            logger.warn("Skipping endpoint with empty path.");
            return;
        }
        if (methods == null || methods.isEmpty()) {
            logger.warn("Skipping endpoint '{}' with no HTTP methods defined.", path);
            return;
        }

        // Create RequestMappingInfo for each HTTP method for this path
        Set<RequestMethod> requestMethods = methods.stream()
                .map(String::toUpperCase)
                .map(RequestMethod::valueOf)
                .collect(Collectors.toSet());

        RequestMappingInfo mappingInfo = RequestMappingInfo.paths(path)
                .methods(requestMethods.toArray(new RequestMethod[0]))
                .produces(MediaType.APPLICATION_JSON_VALUE)
                .build();

        // Register handler method
        Method handlerMethod = this.getClass().getDeclaredMethod("handleRequest",
                HttpServletRequest.class, HttpServletResponse.class);

        // Register mapping
        handlerMapping.registerMapping(mappingInfo, this, handlerMethod);

        // Save endpoint info for use in handler
        endpointMap.put(path, endpoint);

        logger.info("Registered dynamic endpoint: {} [{}]", path, methods);
    }

    // Map from path to EndpointDefinition for lookup in handler
    private final Map<String, EndpointDefinition> endpointMap = new HashMap<>();

    /**
     * Unified handler method for all dynamic endpoints.
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     * @return ResponseEntity with JSON body or error
     */
    public ResponseEntity<Object> handleRequest(HttpServletRequest request, HttpServletResponse response) {
        String path = request.getRequestURI();
        EndpointDefinition endpoint = endpointMap.get(path);
        if (endpoint == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "Endpoint not found"));
        }

        try {
            Map<String, Object> inputParams = extractInputParameters(request, endpoint);
            List<Map<String, Object>> sqlResults = executeSql(endpoint.getQuery(), inputParams);
            List<Map<String, Object>> processedOutput = mapOutputFields(sqlResults, endpoint.getOutputMappings());
            return ResponseEntity.ok(processedOutput);
        } catch (IllegalArgumentException ex) {
            logger.warn("Validation error: {}", ex.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(Map.of("error", ex.getMessage()));
        } catch (Exception ex) {
            logger.error("Error processing request: {}", ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(Map.of("error", "Internal server error"));
        }
    }

    private Map<String, Object> extractInputParameters(HttpServletRequest request, EndpointDefinition endpoint) {
        Map<String, Object> inputParams = new HashMap<>();
        List<InputField> inputFields = endpoint.getInputFields();
        if (inputFields == null) {
            return inputParams;
        }

        for (InputField inputField : inputFields) {
            String name = inputField.getName();
            String type = inputField.getType();
            boolean required = inputField.isRequired();

            String rawValue = null;

            // Support GET query parameters and POST form or JSON parameters
            if ("GET".equalsIgnoreCase(request.getMethod())) {
                rawValue = request.getParameter(name);
            } else if ("POST".equalsIgnoreCase(request.getMethod()) ||
                    "PUT".equalsIgnoreCase(request.getMethod()) ||
                    "PATCH".equalsIgnoreCase(request.getMethod())) {
                // Try parameter first (form), else try JSON body parsing
                rawValue = request.getParameter(name);
                if (rawValue == null) {
                    // Attempt JSON parsing
                    // Since no direct JSON parsing here, throw error for missing param
                }
            }

            if (required && (rawValue == null || rawValue.isBlank())) {
                throw new IllegalArgumentException("Missing required parameter: " + name);
            }

            if (rawValue == null) {
                continue; // skip optional param if not present
            }

            Object parsedValue = parseAndValidateInput(rawValue, inputField);
            inputParams.put(name, parsedValue);
        }
        return inputParams;
    }

    private Object parseAndValidateInput(String rawValue, InputField inputField) {
        String type = inputField.getType();
        if (type == null) {
            type = "string";
        }
        switch (type.toLowerCase()) {
            case "string" -> {
                if (inputField.getValidationRules() != null && inputField.getValidationRules().getRegex() != null) {
                    String regex = inputField.getValidationRules().getRegex();
                    if (!Pattern.matches(regex, rawValue)) {
                        throw new IllegalArgumentException("Parameter '" + inputField.getName() + "' does not match regex pattern.");
                    }
                }
                return rawValue;
            }
            case "integer" -> {
                try {
                    int intValue = Integer.parseInt(rawValue);
                    if (inputField.getValidationRules() != null) {
                        Integer min = inputField.getValidationRules().getMin();
                        Integer max = inputField.getValidationRules().getMax();
                        if (min != null && intValue < min) {
                            throw new IllegalArgumentException("Parameter '" + inputField.getName() + "' must be >= " + min);
                        }
                        if (max != null && intValue > max) {
                            throw new IllegalArgumentException("Parameter '" + inputField.getName() + "' must be <= " + max);
                        }
                    }
                    return intValue;
                } catch (NumberFormatException ex) {
                    throw new IllegalArgumentException("Parameter '" + inputField.getName() + "' must be an integer.");
                }
            }
            case "long" -> {
                try {
                    long longValue = Long.parseLong(rawValue);
                    if (inputField.getValidationRules() != null) {
                        Long min = inputField.getValidationRules().getMinLong();
                        Long max = inputField.getValidationRules().getMaxLong();
                        if (min != null && longValue < min) {
                            throw new IllegalArgumentException("Parameter '" + inputField.getName() + "' must be >= " + min);
                        }
                        if (max != null && longValue > max) {
                            throw new IllegalArgumentException("Parameter '" + inputField.getName() + "' must be <= " + max);
                        }
                    }
                    return longValue;
                } catch (NumberFormatException ex) {
                    throw new IllegalArgumentException("Parameter '" + inputField.getName() + "' must be a long integer.");
                }
            }
            case "date" -> {
                try {
                    // Accept yyyy-MM-dd format only for simplicity
                    return Date.valueOf(rawValue);
                } catch (IllegalArgumentException ex) {
                    throw new IllegalArgumentException("Parameter '" + inputField.getName() + "' must be a date in yyyy-MM-dd format.");
                }
            }
            case "boolean" -> {
                if ("true".equalsIgnoreCase(rawValue) || "false".equalsIgnoreCase(rawValue)) {
                    return Boolean.parseBoolean(rawValue);
                } else {
                    throw new IllegalArgumentException("Parameter '" + inputField.getName() + "' must be a boolean (true/false).");
                }
            }
            default -> throw new IllegalArgumentException("Unsupported parameter type for '" + inputField.getName() + "': " + type);
        }
    }

    private List<Map<String, Object>> executeSql(QueryDefinition queryDefinition, Map<String, Object> inputParams) {
        if (queryDefinition == null || queryDefinition.getSqlTemplate() == null) {
            throw new IllegalArgumentException("SQL query definition is missing.");
        }
        String sqlTemplate = queryDefinition.getSqlTemplate();

        Map<String, String> paramMappings = queryDefinition.getParameters();
        Map<String, Object> sqlParams = new HashMap<>();

        if (paramMappings != null) {
            for (Map.Entry<String, String> entry : paramMappings.entrySet()) {
                String sqlParam = entry.getKey();
                String inputFieldName = entry.getValue();
                if (!inputParams.containsKey(inputFieldName)) {
                    throw new IllegalArgumentException("Missing input parameter for SQL: " + inputFieldName);
                }
                sqlParams.put(sqlParam, inputParams.get(inputFieldName));
            }
        }

        // NamedParameterJdbcTemplate would be ideal, but since only JdbcTemplate is required,
        // we will parse parameters manually and use JdbcTemplate query with args.

        // To keep it simple and safe, we require that SQL uses named parameters with ":" prefix,
        // and we replace them by '?' and prepare argument array in order.

        // Parse SQL template to replace :param with ? and collect parameters in order
        List<Object> args = new ArrayList<>();
        String parsedSql = sqlTemplate;

        if (sqlParams.isEmpty()) {
            // No parameters, run query directly
            return jdbcTemplate.queryForList(sqlTemplate);
        }

        // Simple regex to find :paramName occurrences
        List<String> paramOrder = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        int idx = 0;
        while (idx < parsedSql.length()) {
            int colonIdx = parsedSql.indexOf(':', idx);
            if (colonIdx == -1) {
                sb.append(parsedSql.substring(idx));
                break;
            }
            sb.append(parsedSql, idx, colonIdx);
            int endIdx = colonIdx + 1;
            while (endIdx < parsedSql.length() && (Character.isLetterOrDigit(parsedSql.charAt(endIdx)) || parsedSql.charAt(endIdx) == '_')) {
                endIdx++;
            }
            String paramName = parsedSql.substring(colonIdx + 1, endIdx);
            if (!sqlParams.containsKey(paramName)) {
                throw new IllegalArgumentException("SQL parameter '" + paramName + "' not provided in input mappings.");
            }
            sb.append('?');
            paramOrder.add(paramName);
            idx = endIdx;
        }
        parsedSql = sb.toString();
        for (String param : paramOrder) {
            args.add(sqlParams.get(param));
        }

        List<Map<String, Object>> rows = jdbcTemplate.queryForList(parsedSql, args.toArray());
        return rows;
    }

    private List<Map<String, Object>> mapOutputFields(List<Map<String, Object>> sqlResults, List<OutputFieldMapping> outputMappings) {
        if (sqlResults == null) {
            return Collections.emptyList();
        }
        if (outputMappings == null || outputMappings.isEmpty()) {
            // Return raw sql results if no mappings defined
            return sqlResults;
        }
        List<Map<String, Object>> mappedResults = new ArrayList<>();
        for (Map<String, Object> row : sqlResults) {
            Map<String, Object> mappedRow = new LinkedHashMap<>();
            for (OutputFieldMapping mapping : outputMappings) {
                String sourceColumn = mapping.getSourceColumn();
                String targetField = mapping.getTargetField();
                Object value = row.get(sourceColumn);
                if (mapping.getProcessingLogic() != null && !mapping.getProcessingLogic().isBlank()) {
                    value = applyProcessingLogic(value, mapping.getProcessingLogic());
                }
                mappedRow.put(targetField, value);
            }
            mappedResults.add(mappedRow);
        }
        return mappedResults;
    }

    private Object applyProcessingLogic(Object value, String processingLogic) {
        // Simple processing logic implementation:
        // For now support only toUpperCase, toLowerCase, and date format yyyy-MM-dd
        if (value == null) {
            return null;
        }
        try {
            return switch (processingLogic.toLowerCase()) {
                case "touppercase" -> value.toString().toUpperCase();
                case "tolowercase" -> value.toString().toLowerCase();
                case "date_yyyy-mm-dd" -> {
                    if (value instanceof Date) {
                        yield value.toString();
                    } else if (value instanceof java.util.Date d) {
                        yield new java.text.SimpleDateFormat("yyyy-MM-dd").format(d);
                    } else {
                        yield value.toString();
                    }
                }
                default -> value;
            };
        } catch (Exception ex) {
            logger.warn("Failed to apply processing logic '{}': {}", processingLogic, ex.getMessage());
            return value;
        }
    }
}
