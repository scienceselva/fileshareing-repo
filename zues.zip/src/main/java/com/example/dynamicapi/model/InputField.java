package com.example.dynamicapi.model;

import java.util.Map;

public class InputField {

    private String name;
    private String type;
    private boolean required;
    private ValidationRules validationRules;

    public InputField() {
    }

    public InputField(String name, String type, boolean required, ValidationRules validationRules) {
        this.name = name;
        this.type = type;
        this.required = required;
        this.validationRules = validationRules;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public boolean isRequired() {
		return required;
	}

	public void setRequired(boolean required) {
		this.required = required;
	}

	public ValidationRules getValidationRules() {
		return validationRules;
	}

	public void setValidationRules(ValidationRules validationRules) {
		this.validationRules = validationRules;
	}

    @SuppressWarnings("unchecked")
    public static InputField fromMap(Map<String, Object> map) {
        InputField inputField = new InputField();
        inputField.name = (String) map.get("name");
        inputField.type = (String) map.getOrDefault("type", "string");
        Object requiredObj = map.get("required");
        inputField.required = requiredObj instanceof Boolean b && b;

        Object validationRulesObj = map.get("validationRules");
        if (validationRulesObj instanceof Map<?, ?> vrMap) {
            ValidationRules validationRules = ValidationRules.fromMap((Map<String, Object>) vrMap);
            inputField.validationRules = validationRules;
        }
        return inputField;
    }

    public static class ValidationRules {
        private String regex;
        private Integer min;
        private Integer max;
        private Long minLong;
        private Long maxLong;

        public ValidationRules() {
        }

        public ValidationRules(String regex, Integer min, Integer max, Long minLong, Long maxLong) {
            this.regex = regex;
            this.min = min;
            this.max = max;
            this.minLong = minLong;
            this.maxLong = maxLong;
        }

        public String getRegex() {
            return regex;
        }

        public void setRegex(String regex) {
            this.regex = regex;
        }

        public Integer getMin() {
            return min;
        }

        public void setMin(Integer min) {
            this.min = min;
        }

        public Integer getMax() {
            return max;
        }

        public void setMax(Integer max) {
            this.max = max;
        }

        public Long getMinLong() {
            return minLong;
        }

        public void setMinLong(Long minLong) {
            this.minLong = minLong;
        }

        public Long getMaxLong() {
            return maxLong;
        }

        public void setMaxLong(Long maxLong) {
            this.maxLong = maxLong;
        }

        @SuppressWarnings("unchecked")
        public static ValidationRules fromMap(Map<String, Object> map) {
            ValidationRules vr = new ValidationRules();
            vr.regex = (String) map.get("regex");
            Object minObj = map.get("min");
            if (minObj instanceof Number n) {
                vr.min = n.intValue();
            }
            Object maxObj = map.get("max");
            if (maxObj instanceof Number n) {
                vr.max = n.intValue();
            }
            Object minLongObj = map.get("minLong");
            if (minLongObj instanceof Number n) {
                vr.minLong = n.longValue();
            }
            Object maxLongObj = map.get("maxLong");
            if (maxLongObj instanceof Number n) {
                vr.maxLong = n.longValue();
            }
            return vr;
        }
    }
}
