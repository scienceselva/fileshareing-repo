package com.example.dynamicapi.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class EndpointDefinition {

    private String path;
    private List<String> methods;
    private QueryDefinition query;
    private List<InputField> inputFields;
    private List<OutputFieldMapping> outputMappings;

    public EndpointDefinition() {
    }

    public EndpointDefinition(String path, List<String> methods, QueryDefinition query, List<InputField> inputFields, List<OutputFieldMapping> outputMappings) {
        this.path = path;
        this.methods = methods;
        this.query = query;
        this.inputFields = inputFields;
        this.outputMappings = outputMappings;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public List<String> getMethods() {
        return methods;
    }

    public void setMethods(List<String> methods) {
        this.methods = methods;
    }

    public QueryDefinition getQuery() {
        return query;
    }

    public void setQuery(QueryDefinition query) {
        this.query = query;
    }

    public List<InputField> getInputFields() {
        return inputFields;
    }

    public void setInputFields(List<InputField> inputFields) {
        this.inputFields = inputFields;
    }

    public List<OutputFieldMapping> getOutputMappings() {
        return outputMappings;
    }

    public void setOutputMappings(List<OutputFieldMapping> outputMappings) {
        this.outputMappings = outputMappings;
    }

    @SuppressWarnings("unchecked")
    public static List<EndpointDefinition> fromList(List<?> rawList) {
        List<EndpointDefinition> list = new ArrayList<>();
        if (rawList == null) {
            return list;
        }
        for (Object obj : rawList) {
            if (!(obj instanceof Map<?, ?> map)) {
                continue;
            }
            EndpointDefinition endpoint = new EndpointDefinition();

            endpoint.path = (String) map.get("path");

            Object methodsObj = map.get("methods");
            if (methodsObj instanceof List<?> methodsList) {
                List<String> methods = new ArrayList<>();
                for (Object m : methodsList) {
                    if (m != null)
                        methods.add(m.toString());
                }
                endpoint.methods = methods;
            }

            Object queryObj = map.get("query");
            if (queryObj instanceof Map<?, ?> queryMap) {
                QueryDefinition queryDefinition = QueryDefinition.fromMap((Map<String, Object>) queryMap);
                endpoint.query = queryDefinition;
            }

            Object inputFieldsObj = map.get("inputFields");
            if (inputFieldsObj instanceof List<?> inputFieldsList) {
                List<InputField> inputFields = new ArrayList<>();
                for (Object inputObj : inputFieldsList) {
                    if (inputObj instanceof Map<?, ?> inputMap) {
                        InputField inputField = InputField.fromMap((Map<String, Object>) inputMap);
                        inputFields.add(inputField);
                    }
                }
                endpoint.inputFields = inputFields;
            }

            Object outputMappingsObj = map.get("outputMappings");
            if (outputMappingsObj instanceof List<?> outputMappingsList) {
                List<OutputFieldMapping> outputMappings = new ArrayList<>();
                for (Object outputObj : outputMappingsList) {
                    if (outputObj instanceof Map<?, ?> outputMap) {
                        OutputFieldMapping outputFieldMapping = OutputFieldMapping.fromMap((Map<String, Object>) outputMap);
                        outputMappings.add(outputFieldMapping);
                    }
                }
                endpoint.outputMappings = outputMappings;
            }

            list.add(endpoint);
        }
        return list;
    }
}
