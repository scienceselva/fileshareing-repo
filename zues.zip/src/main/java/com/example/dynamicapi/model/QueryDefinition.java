package com.example.dynamicapi.model;

import java.util.HashMap;
import java.util.Map;

public class QueryDefinition {

    private String sqlTemplate;
    private Map<String, String> parameters;

    public QueryDefinition() {
    }

    public QueryDefinition(String sqlTemplate, Map<String, String> parameters) {
        this.sqlTemplate = sqlTemplate;
        this.parameters = parameters;
    }

    public String getSqlTemplate() {
        return sqlTemplate;
    }

    public void setSqlTemplate(String sqlTemplate) {
        this.sqlTemplate = sqlTemplate;
    }

    public Map<String, String> getParameters() {
        return parameters;
    }

    public void setParameters(Map<String, String> parameters) {
        this.parameters = parameters;
    }

    @SuppressWarnings("unchecked")
    public static QueryDefinition fromMap(Map<String, Object> map) {
        QueryDefinition query = new QueryDefinition();
        query.sqlTemplate = (String) map.get("sqlTemplate");
        Object paramsObj = map.get("parameters");
        if (paramsObj instanceof Map<?, ?> paramsMap) {
            Map<String, String> params = new HashMap<>();
            for (var e : paramsMap.entrySet()) {
                params.put(e.getKey().toString(), e.getValue().toString());
            }
            query.parameters = params;
        }
        return query;
    }
}
