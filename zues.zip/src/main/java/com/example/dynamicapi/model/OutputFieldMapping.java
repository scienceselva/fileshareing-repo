package com.example.dynamicapi.model;

import java.util.Map;

public class OutputFieldMapping {

    private String sourceColumn;
    private String targetField;
    private String processingLogic;

    public OutputFieldMapping() {
    }

    public OutputFieldMapping(String sourceColumn, String targetField, String processingLogic) {
        this.sourceColumn = sourceColumn;
        this.targetField = targetField;
        this.processingLogic = processingLogic;
    }

    public String getSourceColumn() {
        return sourceColumn;
    }

    public void setSourceColumn(String sourceColumn) {
        this.sourceColumn = sourceColumn;
    }

    public String getTargetField() {
        return targetField;
    }

    public void setTargetField(String targetField) {
        this.targetField = targetField;
    }

    public String getProcessingLogic() {
        return processingLogic;
    }

    public void setProcessingLogic(String processingLogic) {
        this.processingLogic = processingLogic;
    }

    @SuppressWarnings("unchecked")
    public static OutputFieldMapping fromMap(Map<String, Object> map) {
        OutputFieldMapping mapping = new OutputFieldMapping();
        mapping.sourceColumn = (String) map.get("sourceColumn");
        mapping.targetField = (String) map.get("targetField");
        mapping.processingLogic = (String) map.get("processingLogic");
        return mapping;
    }
}
