class UIApplication {
  constructor() {
    this.config = null;
    this.currentRowId = 0;
    this.currentModal = null;
    this.runMenuManager = null;
    this.init();
  }

  async init() {
    await this.loadConfig();
    this.setupEventListeners();
    this.populateUI();
    this.populateServiceTable();
    this.initializeRunMenu();
  }
  // Initialize Run Menu
  initializeRunMenu() {
    if (window.RunMenuManager) {
      this.runMenuManager = new RunMenuManager();
      this.runMenuManager.init();
    }
  }


  async loadConfig() {
    try {
      const response = await fetch('./config.json');
      this.config = await response.json();
    } catch (error) {
      console.error('Failed to load configuration:', error);
      // Fallback configuration
      this.config = {
        labels: {
          brand: "Brand",
          environment: "Environment",
          serialNo: "S.No.",
          select: "Select",
          serviceName: "Service Name",
          routes: "Routes",
          size: "Size",
          action: "Action",
          cmdAction: "Cmd-Action"
        },
        brands: ["brand1", "brand2", "brand3"],
        environments: ["SIT", "NFT", "UAT", "PRE_PROD", "PRD"],
        actions: ["start", "stop", "deploy", "map", "unmap", "create", "update", "get"],
        routes: ["/api/users", "/api/products", "/api/orders"],
        services: ["user-service", "product-service", "order-service"],
        syntaxHighlighting: {
          keywords: ["start", "stop", "deploy", "map", "unmap", "create", "update", "get"]
        }
      };
    }
  }

  setupEventListeners() {
    // Menu navigation
    document.getElementById('buildMenu').addEventListener('click', () => this.showMenu('build'));
    document.getElementById('runMenu').addEventListener('click', () => this.showMenu('run'));

    // Command output controls
    document.getElementById('saveBtn').addEventListener('click', () => this.saveCommands());
    document.getElementById('clearBtn').addEventListener('click', () => this.clearCommands());

    // Modal controls
    document.getElementById('closeModal').addEventListener('click', () => this.closeModal());
    document.getElementById('modalCancel').addEventListener('click', () => this.closeModal());
    document.getElementById('modalSave').addEventListener('click', () => this.saveParameters());

    // Close modal when clicking outside
    document.getElementById('parameterModal').addEventListener('click', (e) => {
      if (e.target.id === 'parameterModal') {
        this.closeModal();
      }
    });
  }

  populateUI() {
    // Update labels
    Object.keys(this.config.labels).forEach(key => {
      const element = document.getElementById(key + 'Label') || 
                     document.getElementById(key + 'Header');
      if (element) {
        element.textContent = this.config.labels[key];
      }
    });

    // Populate brand dropdown
    const brandSelect = document.getElementById('brandSelect');
    this.config.brands.forEach(brand => {
      const option = document.createElement('option');
      option.value = brand;
      option.textContent = brand;
      brandSelect.appendChild(option);
    });

    // Populate environment dropdown
    const environmentSelect = document.getElementById('environmentSelect');
    this.config.environments.forEach(env => {
      const option = document.createElement('option');
      option.value = env;
      option.textContent = env;
      environmentSelect.appendChild(option);
    });
  }

  showMenu(menu) {
    // Update navigation buttons
    document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
    document.getElementById(menu + 'Menu').classList.add('active');

    // Update content visibility
    document.querySelectorAll('.menu-content').forEach(content => content.classList.remove('active'));
    document.getElementById(menu + 'Content').classList.add('active');

    // Initialize Run Menu UI when switching to Run menu
    if (menu === 'run' && this.runMenuManager) {
      this.runMenuManager.setupRunMenuUI();
    }
  }

  populateServiceTable() {
    const tbody = document.getElementById('tableBody');
    tbody.innerHTML = '';

    this.config.services.forEach((service, index) => {
      const rowId = index + 1;
      const row = document.createElement('tr');
      row.id = `row-${rowId}`;
      
      row.innerHTML = `
        <td>${rowId}</td>
        <td>
          <input type="checkbox" id="select-${rowId}" onchange="app.toggleRowEdit(${rowId})">
        </td>
        <td>
          <label id="service-${rowId}">${service}</label>
        </td>
        <td>
          <select id="action-${rowId}" disabled onchange="app.handleActionChange(${rowId})">
            <option value="">Select Action</option>
            ${this.config.actions.map(action => `<option value="${action}">${action}</option>`).join('')}
          </select>
        </td>
        <td>
          <button class="btn btn-primary btn-small" onclick="app.addCommand(${rowId})" disabled id="add-${rowId}">Add</button>
        </td>
      `;
      
      tbody.appendChild(row);
    });
  }

  toggleRowEdit(rowId) {
    const isSelected = document.getElementById(`select-${rowId}`).checked;
    const row = document.getElementById(`row-${rowId}`);
    
    // Toggle disabled state for action select
    const actionSelect = row.querySelector('select');
    if (actionSelect && actionSelect.id !== `select-${rowId}`) {
      actionSelect.disabled = !isSelected;
    }

    // Toggle add button
    const addBtn = document.getElementById(`add-${rowId}`);
    if (addBtn) {
      addBtn.disabled = !isSelected;
    }
  }

  handleActionChange(rowId) {
    const actionSelect = document.getElementById(`action-${rowId}`);
    const action = actionSelect.value;
    
    // Check if action requires parameters
    const parameterActions = ['create', 'update', 'map', 'unmap'];
    if (parameterActions.includes(action)) {
      this.showParameterModal(rowId, action);
    }
  }

  showParameterModal(rowId, action) {
    this.currentModal = { rowId, action };
    const modal = document.getElementById('parameterModal');
    const title = document.getElementById('modalTitle');
    
    title.textContent = `Configure ${action.toUpperCase()} for Service`;
    
    // Populate routes in modal
    this.populateModalRoutes();
    
    modal.classList.add('show');
    
    // Clear previous inputs
    document.getElementById('parameterInput').value = '';
    document.getElementById('sizeInput').value = '';
  }

  populateModalRoutes() {
    const routesContainer = document.getElementById('routesInput');
    routesContainer.innerHTML = '';
    
    this.config.routes.forEach((route, index) => {
      const routeItem = document.createElement('div');
      routeItem.className = 'route-item';
      routeItem.innerHTML = `
        <input type="checkbox" id="modal-route-${index}" value="${route}">
        <label for="modal-route-${index}">${route}</label>
      `;
      routesContainer.appendChild(routeItem);
    });
  }

  closeModal() {
    document.getElementById('parameterModal').classList.remove('show');
    this.currentModal = null;
  }

  saveParameters() {
    if (!this.currentModal) return;
    
    const parameters = document.getElementById('parameterInput').value;
    const size = document.getElementById('sizeInput').value;
    const { rowId, action } = this.currentModal;
    
    // Get selected routes
    const selectedRoutes = [];
    const routeCheckboxes = document.querySelectorAll('#routesInput input[type="checkbox"]:checked');
    routeCheckboxes.forEach(checkbox => {
      selectedRoutes.push(checkbox.value);
    });
    
    // Store data in action select element
    const actionSelect = document.getElementById(`action-${rowId}`);
    actionSelect.setAttribute('data-parameters', parameters);
    actionSelect.setAttribute('data-size', size);
    actionSelect.setAttribute('data-routes', JSON.stringify(selectedRoutes));
    
    this.closeModal();
  }

  addCommand(rowId) {
    const brand = document.getElementById('brandSelect').value;
    const environment = document.getElementById('environmentSelect').value;
    const serviceLabel = document.getElementById(`service-${rowId}`);
    const service = serviceLabel.textContent;
    const action = document.getElementById(`action-${rowId}`).value;
    const actionSelect = document.getElementById(`action-${rowId}`);
    
    // Get stored data from modal
    const parameters = actionSelect.getAttribute('data-parameters') || '';
    const size = actionSelect.getAttribute('data-size') || '';
    const routesData = actionSelect.getAttribute('data-routes');
    const selectedRoutes = routesData ? JSON.parse(routesData) : [];

    // Validate required fields
    if (!brand || !environment || !service || !action) {
      alert('Please fill in all required fields: Brand, Environment, Service Name, and Action');
      return;
    }

    // Build command
    let command = `${action} --brand=${brand} --environment=${environment} --service=${service}`;
    
    if (selectedRoutes.length > 0) {
      command += ` --routes="${selectedRoutes.join(',')}"`;
    }
    
    if (size) {
      command += ` --size=${size}`;
    }
    
    if (parameters) {
      command += ` --parameters="${parameters}"`;
    }

    // Add to output area with syntax highlighting
    this.addCommandToOutput(command);
  }

  addCommandToOutput(command) {
    const output = document.getElementById('commandOutput');
    const currentValue = output.value;
    const newValue = currentValue ? currentValue + '\n' + command : command;
    
    output.value = newValue;
    
    // Scroll to bottom
    output.scrollTop = output.scrollHeight;
    
    // Apply syntax highlighting
    this.applySyntaxHighlighting();
  }

  applySyntaxHighlighting() {
    const textarea = document.getElementById('commandOutput');
    const text = textarea.value;
    
    // Create a div overlay for syntax highlighting
    let highlightDiv = document.getElementById('syntaxHighlight');
    if (!highlightDiv) {
      highlightDiv = document.createElement('div');
      highlightDiv.id = 'syntaxHighlight';
      highlightDiv.className = 'syntax-overlay';
      textarea.parentNode.insertBefore(highlightDiv, textarea);
    }
    
    // Apply syntax highlighting
    const keywords = this.config.syntaxHighlighting.keywords;
    let highlightedText = text;
    
    // Escape HTML characters
    highlightedText = highlightedText
      .replace(/&/g, '&')
      .replace(/</g, '<')
      .replace(/>/g, '>');
    
    // First, highlight parameters with values (--parameter=value)
    highlightedText = highlightedText.replace(
      /--([a-zA-Z0-9_-]+)=([^\s]+)/g, 
      '<span class="syntax-parameter">--$1</span>=<span class="syntax-value">$2</span>'
    );
    
    // Then highlight standalone parameters (--parameter without =)
    highlightedText = highlightedText.replace(
      /--([a-zA-Z0-9_-]+)(?!=)/g, 
      '<span class="syntax-parameter">--$1</span>'
    );
    
    // Finally, highlight keywords (start, stop, deploy, etc.) in pink
    keywords.forEach(keyword => {
      const regex = new RegExp(`\\b(${keyword})\\b`, 'gi');
      highlightedText = highlightedText.replace(regex, '<span class="syntax-keyword">$1</span>');
    });
    
    // Convert newlines to <br> tags
    highlightedText = highlightedText.replace(/\n/g, '<br>');
    
    highlightDiv.innerHTML = highlightedText;
  }

  saveCommands() {
    const output = document.getElementById('commandOutput').value;
    if (!output.trim()) {
      alert('No commands to save');
      return;
    }

    // Create a download link
    const blob = new Blob([output], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `commands_${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    alert('Commands saved successfully!');
  }

  clearCommands() {
    if (confirm('Are you sure you want to clear all commands?')) {
      document.getElementById('commandOutput').value = '';
      // Clear syntax highlighting overlay
      const highlightDiv = document.getElementById('syntaxHighlight');
      if (input.id !== `select-${rowId}`) {
        highlightDiv.innerHTML = '';
      }
    }
  }

  handleActionChange(rowId) {
    const actionSelect = document.getElementById(`action-${rowId}`);
    const action = actionSelect.value;
    
    // Check if action requires parameters
    const parameterActions = ['create', 'update', 'map', 'unmap'];
    if (parameterActions.includes(action)) {
      this.showParameterModal(rowId, action);
    }
  }

  showParameterModal(rowId, action) {
    this.currentModal = { rowId, action };
    const modal = document.getElementById('parameterModal');
    const title = document.getElementById('modalTitle');
    
    title.textContent = `Enter Parameters for ${action.toUpperCase()}`;
    modal.classList.add('show');
    
    // Clear previous input
    document.getElementById('parameterInput').value = '';
  }

  closeModal() {
    document.getElementById('parameterModal').classList.remove('show');
    this.currentModal = null;
  }

  saveParameters() {
    if (!this.currentModal) return;
    
    const parameters = document.getElementById('parameterInput').value;
    const { rowId, action } = this.currentModal;
    
    // Store parameters in a data attribute
    const actionSelect = document.getElementById(`action-${rowId}`);
    actionSelect.setAttribute('data-parameters', parameters);
    
    this.closeModal();
  }

  addCommand(rowId) {
    const brand = document.getElementById('brandSelect').value;
    const environment = document.getElementById('environmentSelect').value;
    const service = document.getElementById(`service-${rowId}`).innerHTML;
    const size = "" //document.getElementById(`size-${rowId}`).value;
    const action = document.getElementById(`action-${rowId}`).value;
    const actionSelect = document.getElementById(`action-${rowId}`);
    const parameters = actionSelect.getAttribute('data-parameters') || '';

    // Get selected routes
    const selectedRoutes = [];
    const routeCheckboxes = document.querySelectorAll(`#routes-${rowId} input[type="checkbox"]:checked`);
    routeCheckboxes.forEach(checkbox => {
      selectedRoutes.push(checkbox.value);
    });

    console.log(brand, environment, service, action);
    // Validate required fields
    if (!brand || !environment || !service || !action) {
      alert('Please fill in all required fields: Brand, Environment, Service Name, and Action');
      return;
    }

    // Build command
    let command = `${action} --brand=${brand} --environment=${environment} --service=${service}`;
    
    if (selectedRoutes.length > 0) {
      command += ` --routes="${selectedRoutes.join(',')}"`;
    }
    
    if (size) {
      command += ` --size=${size}`;
    }
    
    if (parameters) {
      command += ` --parameters="${parameters}"`;
    }

    // Add to output area with syntax highlighting
    this.addCommandToOutput(command);
  }

  addCommandToOutput(command) {
    const output = document.getElementById('commandOutput');
    const currentValue = output.value;
    const newValue = currentValue ? currentValue + '\n' + command : command;
    
    output.value = newValue;
    
    // Scroll to bottom
    output.scrollTop = output.scrollHeight;
    
    // Apply syntax highlighting
    this.applySyntaxHighlighting();
  }

  applySyntaxHighlighting() {
    const textarea = document.getElementById('commandOutput');
    const text = textarea.value;
    
    // Create a div overlay for syntax highlighting
    let highlightDiv = document.getElementById('syntaxHighlight');
    if (!highlightDiv) {
      highlightDiv = document.createElement('div');
      highlightDiv.id = 'syntaxHighlight';
      highlightDiv.className = 'syntax-overlay';
      textarea.parentNode.insertBefore(highlightDiv, textarea);
    }
    
    // Apply syntax highlighting
    const keywords = this.config.syntaxHighlighting.keywords;
    let highlightedText = text;
    
    // Escape HTML characters
    highlightedText = highlightedText
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
    
    // First, highlight parameters with values (--parameter=value)
    highlightedText = highlightedText.replace(
      /--([a-zA-Z0-9_-]+)=([^\s]+)/g, 
      '<span class="syntax-parameter">--$1</span>=<span class="syntax-value">$2</span>'
    );
    
    // Then highlight standalone parameters (--parameter without =)
    highlightedText = highlightedText.replace(
      /--([a-zA-Z0-9_-]+)(?!=)/g, 
      '<span class="syntax-parameter">--$1</span>'
    );
    
    // Finally, highlight keywords (start, stop, deploy, etc.) in pink
    keywords.forEach(keyword => {
      const regex = new RegExp(`\\b(${keyword})\\b`, 'gi');
      highlightedText = highlightedText.replace(regex, '<span class="syntax-keyword">$1</span>');
    });
    
    // Convert newlines to <br> tags
    highlightedText = highlightedText.replace(/\n/g, '<br>');
    
    highlightDiv.innerHTML = highlightedText;
  }

  removeRow(rowId) {
    const row = document.getElementById(`row-${rowId}`);
    if (row) {
      row.remove();
    }
  }

  saveCommands() {
    const output = document.getElementById('commandOutput').value;
    if (!output.trim()) {
      alert('No commands to save');
      return;
    }

    // Create a download link
    const blob = new Blob([output], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `commands_${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    alert('Commands saved successfully!');
  }

  clearCommands() {
    if (confirm('Are you sure you want to clear all commands?')) {
      document.getElementById('commandOutput').value = '';
    }
  }
}

// Initialize the application
let app;
document.addEventListener('DOMContentLoaded', () => {
  app = new UIApplication();
});

// Global functions for onclick handlers
window.app = {
  toggleRowEdit: (rowId) => app.toggleRowEdit(rowId),
  handleActionChange: (rowId) => app.handleActionChange(rowId),
  addCommand: (rowId) => app.addCommand(rowId),
};