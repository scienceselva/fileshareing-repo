// =============================================================================
// RUN MENU MODULE - Isolated functionality for command execution and scheduling
// =============================================================================

class RunMenuManager {
  constructor() {
    this.selectedFiles = [];
    this.fileCommands = new Map(); // Map to store commands for each file
    this.executionResults = new Map(); // Map to store execution results
    this.currentExecution = null;
    this.executionQueue = [];
    this.isExecuting = false;
  }

  // Initialize the Run Menu
  init() {
    this.setupRunMenuEventListeners();
    this.setupRunMenuUI();
  }

  // Setup event listeners for Run Menu
  setupRunMenuEventListeners() {
    // File selection
    const fileInput = document.getElementById('fileInput');
    if (fileInput) {
      fileInput.addEventListener('change', (e) => this.handleFileSelection(e));
    }

    // Execution buttons
    document.getElementById('executeAllSequential')?.addEventListener('click', () => this.executeAllSequential());
    document.getElementById('executeAllParallel')?.addEventListener('click', () => this.executeAllParallel());
    document.getElementById('executeSelectedFile')?.addEventListener('click', () => this.executeSelectedFile());
    document.getElementById('stopExecution')?.addEventListener('click', () => this.stopExecution());
    document.getElementById('clearResults')?.addEventListener('click', () => this.clearExecutionResults());

    // File list interactions
    document.getElementById('fileList')?.addEventListener('click', (e) => this.handleFileListClick(e));
  }

  // Setup Run Menu UI
  setupRunMenuUI() {
    const runContent = document.getElementById('runContent');
    if (!runContent) return;

    runContent.innerHTML = `
      <div class="run-menu-container">
        <!-- Left Panel - File Selection and Commands -->
        <div class="run-left-panel">
          <div class="file-selection-section">
            <div class="section-header">
              <h3>File Selection</h3>
              <input type="file" id="fileInput" multiple accept=".txt,.log,.cmd" class="file-input">
              <label for="fileInput" class="btn btn-primary">Select Command Files</label>
            </div>
            
            <div class="selected-files-info">
              <span id="fileCount">0 files selected</span>
            </div>
          </div>

          <div class="file-list-section">
            <div class="section-header">
              <h3>Files & Commands</h3>
              <div class="execution-controls">
                <button id="executeAllSequential" class="btn btn-success btn-small">Run All (Sequential)</button>
                <button id="executeAllParallel" class="btn btn-warning btn-small">Run All (Parallel)</button>
                <button id="executeSelectedFile" class="btn btn-primary btn-small">Run Selected File</button>
                <button id="stopExecution" class="btn btn-danger btn-small" disabled>Stop</button>
              </div>
            </div>
            
            <div class="file-list-container">
              <div id="fileList" class="file-list">
                <div class="empty-state">
                  <p>No files selected. Choose command files to begin.</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Right Panel - Execution Results -->
        <div class="run-right-panel">
          <div class="execution-results-section">
            <div class="section-header">
              <h3>Execution Results</h3>
              <div class="result-controls">
                <button id="clearResults" class="btn btn-secondary btn-small">Clear Results</button>
                <div class="execution-status">
                  <span id="executionStatus" class="status-idle">Ready</span>
                </div>
              </div>
            </div>
            
            <div class="results-container">
              <div id="executionOutput" class="execution-output" placeholder="Execution results will appear here..."></div>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  // Handle file selection
  async handleFileSelection(event) {
    const files = Array.from(event.target.files);
    this.selectedFiles = files;
    
    // Read file contents
    for (const file of files) {
      try {
        const content = await this.readFileContent(file);
        const commands = this.parseCommands(content);
        this.fileCommands.set(file.name, {
          file: file,
          commands: commands,
          selected: false
        });
      } catch (error) {
        console.error(`Error reading file ${file.name}:`, error);
      }
    }

    this.updateFileList();
    this.updateFileCount();
  }

  // Read file content
  readFileContent(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target.result);
      reader.onerror = (e) => reject(e);
      reader.readAsText(file);
    });
  }

  // Parse commands from file content
  parseCommands(content) {
    return content
      .split('\n')
      .map(line => line.trim())
      .filter(line => line && !line.startsWith('#'))
      .map((command, index) => ({
        id: index + 1,
        command: command,
        selected: true,
        status: 'pending', // pending, running, success, failed
        result: null,
        returnCode: null
      }));
  }

  // Update file list display
  updateFileList() {
    const fileListContainer = document.getElementById('fileList');
    if (!fileListContainer) return;

    if (this.fileCommands.size === 0) {
      fileListContainer.innerHTML = `
        <div class="empty-state">
          <p>No files selected. Choose command files to begin.</p>
        </div>
      `;
      return;
    }

    let html = '';
    this.fileCommands.forEach((fileData, fileName) => {
      const isSelected = fileData.selected ? 'selected' : '';
      html += `
        <div class="file-item ${isSelected}" data-filename="${fileName}">
          <div class="file-header">
            <div class="file-info">
              <input type="checkbox" class="file-checkbox" ${fileData.selected ? 'checked' : ''}>
              <span class="file-name">${fileName}</span>
              <span class="command-count">(${fileData.commands.length} commands)</span>
            </div>
            <button class="btn btn-primary btn-small execute-file-btn" data-filename="${fileName}">
              Run File
            </button>
          </div>
          
          <div class="commands-list">
            ${fileData.commands.map(cmd => `
              <div class="command-item ${cmd.status}" data-filename="${fileName}" data-command-id="${cmd.id}">
                <div class="command-info">
                  <input type="checkbox" class="command-checkbox" ${cmd.selected ? 'checked' : ''}>
                  <span class="command-text">${this.highlightCommand(cmd.command)}</span>
                  <span class="command-status status-${cmd.status}">${cmd.status}</span>
                </div>
                <button class="btn btn-primary btn-small execute-command-btn" data-filename="${fileName}" data-command-id="${cmd.id}">
                  Run
                </button>
              </div>
            `).join('')}
          </div>
        </div>
      `;
    });

    fileListContainer.innerHTML = html;
  }

  // Highlight command syntax
  highlightCommand(command) {
    let highlighted = command;
    
    // Escape HTML
    highlighted = highlighted
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
    
    // Highlight parameters with values (--parameter=value)
    highlighted = highlighted.replace(
      /--([a-zA-Z0-9_-]+)=([^\s]+)/g, 
      '<span class="syntax-parameter">--$1</span>=<span class="syntax-value">$2</span>'
    );
    
    // Highlight standalone parameters (--parameter without =)
    highlighted = highlighted.replace(
      /--([a-zA-Z0-9_-]+)(?!=)/g, 
      '<span class="syntax-parameter">--$1</span>'
    );
    
    // Highlight keywords
    const keywords = ['start', 'stop', 'deploy', 'map', 'unmap', 'create', 'update', 'get'];
    keywords.forEach(keyword => {
      const regex = new RegExp(`\\b(${keyword})\\b`, 'gi');
      highlighted = highlighted.replace(regex, '<span class="syntax-keyword">$1</span>');
    });
    
    return highlighted;
  }

  // Handle file list clicks
  handleFileListClick(event) {
    const target = event.target;
    
    // File checkbox
    if (target.classList.contains('file-checkbox')) {
      const fileName = target.closest('.file-item').dataset.filename;
      const fileData = this.fileCommands.get(fileName);
      if (fileData) {
        fileData.selected = target.checked;
        this.updateFileList();
      }
    }
    
    // Command checkbox
    else if (target.classList.contains('command-checkbox')) {
      const fileName = target.closest('.command-item').dataset.filename;
      const commandId = parseInt(target.closest('.command-item').dataset.commandId);
      const fileData = this.fileCommands.get(fileName);
      if (fileData) {
        const command = fileData.commands.find(cmd => cmd.id === commandId);
        if (command) {
          command.selected = target.checked;
        }
      }
    }
    
    // Execute file button
    else if (target.classList.contains('execute-file-btn')) {
      const fileName = target.dataset.filename;
      this.executeFile(fileName);
    }
    
    // Execute command button
    else if (target.classList.contains('execute-command-btn')) {
      const fileName = target.dataset.filename;
      const commandId = parseInt(target.dataset.commandId);
      this.executeCommand(fileName, commandId);
    }
  }

  // Update file count display
  updateFileCount() {
    const fileCountElement = document.getElementById('fileCount');
    if (fileCountElement) {
      fileCountElement.textContent = `${this.selectedFiles.length} files selected`;
    }
  }

  // Execute all files sequentially
  async executeAllSequential() {
    this.setExecutionStatus('running', 'Executing all files sequentially...');
    this.isExecuting = true;
    
    for (const [fileName, fileData] of this.fileCommands) {
      if (fileData.selected) {
        await this.executeFile(fileName);
        if (!this.isExecuting) break; // Stop if execution was cancelled
      }
    }
    
    this.setExecutionStatus('completed', 'Sequential execution completed');
    this.isExecuting = false;
  }

  // Execute all files in parallel
  async executeAllParallel() {
    this.setExecutionStatus('running', 'Executing all files in parallel...');
    this.isExecuting = true;
    
    const promises = [];
    this.fileCommands.forEach((fileData, fileName) => {
      if (fileData.selected) {
        promises.push(this.executeFile(fileName));
      }
    });
    
    await Promise.all(promises);
    this.setExecutionStatus('completed', 'Parallel execution completed');
    this.isExecuting = false;
  }

  // Execute selected file
  async executeSelectedFile() {
    const selectedFiles = Array.from(this.fileCommands.entries())
      .filter(([fileName, fileData]) => fileData.selected);
    
    if (selectedFiles.length === 0) {
      this.addExecutionOutput('No files selected for execution', 'error');
      return;
    }
    
    if (selectedFiles.length === 1) {
      await this.executeFile(selectedFiles[0][0]);
    } else {
      this.addExecutionOutput('Multiple files selected. Use "Run All" buttons for multiple files.', 'warning');
    }
  }

  // Execute a single file
  async executeFile(fileName) {
    const fileData = this.fileCommands.get(fileName);
    if (!fileData) return;
    
    this.addExecutionOutput(`\n=== Executing File: ${fileName} ===`, 'info');
    
    const selectedCommands = fileData.commands.filter(cmd => cmd.selected);
    
    for (const command of selectedCommands) {
      if (!this.isExecuting) break;
      await this.executeCommand(fileName, command.id);
    }
    
    this.addExecutionOutput(`=== Completed File: ${fileName} ===\n`, 'info');
  }

  // Execute a single command
  async executeCommand(fileName, commandId) {
    const fileData = this.fileCommands.get(fileName);
    if (!fileData) return;
    
    const command = fileData.commands.find(cmd => cmd.id === commandId);
    if (!command) return;
    
    // Update command status
    command.status = 'running';
    this.updateFileList();
    
    this.addExecutionOutput(`> ${command.command}`, 'command');
    
    try {
      // Simulate API call to backend service
      const result = await this.callBackendAPI(command.command);
      
      command.status = result.returnCode === 200 ? 'success' : 'failed';
      command.result = result.output;
      command.returnCode = result.returnCode;
      
      // Add result to output
      this.addExecutionOutput(result.output, command.status === 'success' ? 'success' : 'error');
      this.addExecutionOutput(`Return Code: ${result.returnCode}`, 'info');
      
    } catch (error) {
      command.status = 'failed';
      command.result = error.message;
      command.returnCode = 500;
      
      this.addExecutionOutput(`Error: ${error.message}`, 'error');
      this.addExecutionOutput(`Return Code: 500`, 'info');
    }
    
    this.updateFileList();
  }

  // Simulate backend API call
  async callBackendAPI(command) {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));
    
    // Simulate different outcomes based on command
    const isSuccess = Math.random() > 0.2; // 80% success rate
    
    return {
      returnCode: isSuccess ? 200 : 400,
      output: isSuccess 
        ? `Command executed successfully: ${command}\nOutput: Operation completed successfully.`
        : `Command failed: ${command}\nError: Operation failed with error code.`
    };
  }

  // Add output to execution results
  addExecutionOutput(text, type = 'default') {
    const outputContainer = document.getElementById('executionOutput');
    if (!outputContainer) return;
    
    const timestamp = new Date().toLocaleTimeString();
    const outputLine = document.createElement('div');
    outputLine.className = `output-line output-${type}`;
    
    let formattedText = text;
    if (type === 'command') {
      formattedText = this.highlightCommand(text);
    }
    
    outputLine.innerHTML = `<span class="timestamp">[${timestamp}]</span> ${formattedText}`;
    outputContainer.appendChild(outputLine);
    
    // Scroll to bottom
    outputContainer.scrollTop = outputContainer.scrollHeight;
  }

  // Set execution status
  setExecutionStatus(status, message) {
    const statusElement = document.getElementById('executionStatus');
    const stopButton = document.getElementById('stopExecution');
    
    if (statusElement) {
      statusElement.textContent = message;
      statusElement.className = `status-${status}`;
    }
    
    if (stopButton) {
      stopButton.disabled = status !== 'running';
    }
  }

  // Stop execution
  stopExecution() {
    this.isExecuting = false;
    this.setExecutionStatus('stopped', 'Execution stopped by user');
    this.addExecutionOutput('Execution stopped by user', 'warning');
  }

  // Clear execution results
  clearExecutionResults() {
    const outputContainer = document.getElementById('executionOutput');
    if (outputContainer) {
      outputContainer.innerHTML = '';
    }
    
    // Reset command statuses
    this.fileCommands.forEach(fileData => {
      fileData.commands.forEach(command => {
        command.status = 'pending';
        command.result = null;
        command.returnCode = null;
      });
    });
    
    this.updateFileList();
    this.setExecutionStatus('ready', 'Ready');
  }
}

// Export for use in main application
window.RunMenuManager = RunMenuManager;