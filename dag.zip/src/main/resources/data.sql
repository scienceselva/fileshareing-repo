INSERT INTO users (username, email, basicpay, advancepay) VALUES
('alice', 'alice@example.com', 50000, 10000),
('bob', 'bob@example.com', 60000, 5000),
('charlie', 'charlie@example.com', 75000, 15000);
