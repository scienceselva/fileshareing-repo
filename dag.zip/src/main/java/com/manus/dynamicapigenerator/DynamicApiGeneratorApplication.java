package com.manus.dynamicapigenerator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DynamicApiGeneratorApplication {

	public static void main(String[] args) {
		SpringApplication.run(DynamicApiGeneratorApplication.class, args);
	}

}
