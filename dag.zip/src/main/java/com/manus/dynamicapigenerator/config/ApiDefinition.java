package com.manus.dynamicapigenerator.config;

import lombok.Data;
import java.util.Map;

@Data
public class ApiDefinition {
    private String name;
    private String path;
    private String method;
    private String sql;
    private Map<String, Object> input; // Key: param name, Value: Type (String, Integer, etc.) or Map for complex
    private Map<String, String> output; // Key: output field name, Value: Type
    private Map<String, String> outputfieldmapping; // Key: output field name, Value: SQL column name
    private Map<String, String> processing; // Key: output field name, Value: Processing logic (e.g., ADD (col1 + col2))
}
