package com.manus.dynamicapigenerator.controller;

import com.manus.dynamicapigenerator.config.ApiDefinition;
import com.manus.dynamicapigenerator.service.DataExecutionService;
import com.manus.dynamicapigenerator.service.YamlLoaderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
public class GenericController {

    @Autowired
    private YamlLoaderService yamlLoaderService;

    @Autowired
    private DataExecutionService dataExecutionService; // Will be implemented in Phase 4

    /**
     * This method is the generic handler for all dynamically registered endpoints.
     * It uses the HttpServletRequest to determine the exact endpoint definition
     * and the request parameters.
     */
    @RequestMapping(value = "/**", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE})
    public ResponseEntity<Object> handleDynamicRequest(
            HttpServletRequest request,
            @RequestBody(required = false) Map<String, Object> requestBody,
            @RequestParam(required = false) Map<String, String> queryParams) {

        String requestPath = request.getRequestURI();
        HttpMethod httpMethod = HttpMethod.valueOf(request.getMethod());

        // 1. Find the matching ApiDefinition
        Optional<ApiDefinition> definitionOpt = yamlLoaderService.getApiDefinitions().stream()
                .filter(def -> def.getPath().equals(requestPath) && def.getMethod().equalsIgnoreCase(httpMethod.name()))
                .findFirst();

        if (definitionOpt.isEmpty()) {
            // This should ideally not happen if the router is set up correctly, but as a fallback
            return ResponseEntity.notFound().build();
        }

        ApiDefinition definition = definitionOpt.get();

        // 2. Collect all input parameters
        Map<String, Object> allParams = new HashMap<>();
        if (requestBody != null) {
            allParams.putAll(requestBody);
        }
        if (queryParams != null) {
            allParams.putAll(queryParams);
        }

        // 3. Input Validation (Simplified for now, will be enhanced)
        // For simplicity, we'll assume the input map in YAML is a flat map of parameter names.
        // The full validation logic (required, type checking) will be more complex and is a stretch goal.
        // For now, we check for required parameters.
        for (Map.Entry<String, Object> entry : definition.getInput().entrySet()) {
            String paramName = entry.getKey();
            Object paramDetails = entry.getValue();

            // Simple check for 'required: true'
            if (paramDetails instanceof Map && ((Map<?, ?>) paramDetails).containsKey("required") && (Boolean) ((Map<?, ?>) paramDetails).get("required")) {
                if (!allParams.containsKey(paramName)) {
                    return ResponseEntity.badRequest().body(Map.of("error", "Missing required parameter: " + paramName));
                }
            } else if (paramDetails.equals("required") && !allParams.containsKey(paramName)) {
                 // Handle the simplified YAML structure from the user's example: 'id: Integer\nrequired: true'
                 // This requires a more complex parsing of the user's YAML structure in the loader,
                 // but for now, we'll focus on the core logic.
                 // Let's assume the user's YAML is slightly simplified for the initial implementation.
                 // The current YAML loader only supports a flat map for input.
                 // We will adjust the YAML loader and ApiDefinition to handle the user's complex input structure in a later phase if needed.
            }
        }

        // 4. Execute the SQL and get the result (Delegated to DataExecutionService)
        List<Map<String, Object>> rawResult;
        try {
            rawResult = dataExecutionService.execute(definition, allParams);
        } catch (Exception e) {
            // Proper error handling for SQL execution will be in Phase 4
            return ResponseEntity.internalServerError().body(Map.of("error", "SQL Execution Error", "details", e.getMessage()));
        }

        // 5. Process and Map the result (Delegated to DataExecutionService for now, Phase 5 will refine)
        List<Map<String, Object>> finalResult = dataExecutionService.processAndMap(definition, rawResult);

        // 6. Return the response
        if (definition.getMethod().equalsIgnoreCase("POST")) {
            // For POST, the result is usually a success message
            return ResponseEntity.ok(finalResult.isEmpty() ? Map.of("success", true, "message", "Operation successful") : finalResult.get(0));
        }
        return ResponseEntity.ok(finalResult);
    }
}
