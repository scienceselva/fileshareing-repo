package com.manus.dynamicapigenerator.service;

import com.manus.dynamicapigenerator.config.ApiDefinition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Service
public class JdbcDataExecutionService implements DataExecutionService {

    private final NamedParameterJdbcTemplate jdbcTemplate;

    @Autowired
    public JdbcDataExecutionService(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<Map<String, Object>> execute(ApiDefinition definition, Map<String, Object> params) {
        String sql = definition.getSql();
        MapSqlParameterSource paramSource = new MapSqlParameterSource(params);

        // Determine if it's a SELECT or DML statement
        if (sql.trim().toUpperCase(Locale.ROOT).startsWith("SELECT")) {
            // SELECT statement
            return jdbcTemplate.queryForList(sql, paramSource);
        } else {
            // INSERT, UPDATE, DELETE (DML) statement
            int rowsAffected = jdbcTemplate.update(sql, paramSource);

            // For DML, return a simple success/failure map for the controller to process
            if (rowsAffected > 0) {
                return Collections.singletonList(Map.of("success", true, "message", "Operation successful. Rows affected: " + rowsAffected));
            } else {
                return Collections.singletonList(Map.of("success", false, "message", "Operation failed. No rows affected."));
            }
        }
    }

    @Override
    public List<Map<String, Object>> processAndMap(ApiDefinition definition, List<Map<String, Object>> rawResult) {
        if (rawResult == null || rawResult.isEmpty()) {
            return Collections.emptyList();
        }

        // Handle DML success/failure response
        if (definition.getSql().trim().toUpperCase(Locale.ROOT).startsWith("INSERT") ||
            definition.getSql().trim().toUpperCase(Locale.ROOT).startsWith("UPDATE") ||
            definition.getSql().trim().toUpperCase(Locale.ROOT).startsWith("DELETE")) {
            return rawResult;
        }

        // Handle SELECT results
        return rawResult.stream().map(rawRow -> {
            Map<String, Object> finalRow = new java.util.LinkedHashMap<>();
            Map<String, String> mapping = definition.getOutputfieldmapping();
            Map<String, String> processing = definition.getProcessing();

            // 1. Apply simple field mapping
            if (mapping != null) {
                for (Map.Entry<String, String> entry : mapping.entrySet()) {
                    String outputField = entry.getKey();
                    String sourceField = entry.getValue();
                    finalRow.put(outputField, rawRow.get(sourceField.toLowerCase(Locale.ROOT))); // H2 returns column names in lower case
                }
            }

            // 2. Apply processing logic (e.g., ADD)
            if (processing != null) {
                for (Map.Entry<String, String> entry : processing.entrySet()) {
                    String outputField = entry.getKey();
                    String logic = entry.getValue();

                    // Simple ADD logic: ADD (col1 + col2)
                    if (logic.toUpperCase(Locale.ROOT).startsWith("ADD")) {
                        // Extract column names from the logic string, e.g., "basicpay + advancepay"
                        String expression = logic.substring(logic.indexOf('(') + 1, logic.indexOf(')')).trim();
                        String[] parts = expression.split("\\s*\\+\\s*");

                        long sum = 0;
                        for (String part : parts) {
                            Object value = rawRow.get(part.toLowerCase(Locale.ROOT));
                            if (value instanceof Number) {
                                sum += ((Number) value).longValue();
                            }
                        }
                        finalRow.put(outputField, sum);
                    }
                    // Future logic (SUBTRACT, MULTIPLY, CONCAT, etc.) would go here
                }
            }

            // 3. Ensure all fields in the output definition are present (even if null/default)
            if (definition.getOutput() != null) {
                for (String outputField : definition.getOutput().keySet()) {
                    if (!finalRow.containsKey(outputField)) {
                        finalRow.put(outputField, null);
                    }
                }
            }

            return finalRow;
        }).toList();
    }
}
