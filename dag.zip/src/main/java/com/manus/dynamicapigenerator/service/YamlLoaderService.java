package com.manus.dynamicapigenerator.service;

import com.manus.dynamicapigenerator.config.ApiDefinition;
import com.manus.dynamicapigenerator.config.EndpointConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.Constructor;

import jakarta.annotation.PostConstruct;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

@Service
public class YamlLoaderService {

    @Value("classpath:endpoints.yaml")
    private Resource yamlResource;

    private List<ApiDefinition> apiDefinitions;

    @PostConstruct
    public void loadYaml() {
        Yaml yaml = new Yaml(new Constructor(Map.class));
        try (InputStream inputStream = yamlResource.getInputStream()) {
            Map<String, Object> data = yaml.load(inputStream);
            // Manually parse the structure to List<ApiDefinition>
            List<Map<String, Object>> endpoints = (List<Map<String, Object>>) data.get("endpoints");
            if (endpoints != null) {
                this.apiDefinitions = endpoints.stream().map(this::mapToApiDefinition).toList();
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to load endpoints.yaml", e);
        }
    }

    private ApiDefinition mapToApiDefinition(Map<String, Object> map) {
        ApiDefinition def = new ApiDefinition();
        def.setName((String) map.get("name"));
        def.setPath((String) map.get("path"));
        def.setMethod((String) map.get("method"));
        def.setSql((String) map.get("sql"));
        def.setInput((Map<String, Object>) map.get("input"));
        def.setOutput((Map<String, String>) map.get("output"));
        def.setOutputfieldmapping((Map<String, String>) map.get("outputfieldmapping"));
        def.setProcessing((Map<String, String>) map.get("processing"));
        return def;
    }

    public List<ApiDefinition> getApiDefinitions() {
        return apiDefinitions;
    }
}
