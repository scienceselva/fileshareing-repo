package com.manus.dynamicapigenerator.service;

import com.manus.dynamicapigenerator.config.ApiDefinition;

import java.util.List;
import java.util.Map;

public interface DataExecutionService {
    List<Map<String, Object>> execute(ApiDefinition definition, Map<String, Object> params);
    List<Map<String, Object>> processAndMap(ApiDefinition definition, List<Map<String, Object>> rawResult);
}
