const request = require('supertest');
const app = require('../src/app');

describe('Generic API Tests', () => {
  it('GET /api/users should return valid data', async () => {
    const res = await request(app).get('/api/users?id=1');
    expect(res.statusCode).toBe(200);
    expect(res.body[0]).toHaveProperty('id');
  });

  it('POST /users should insert user', async () => {
    const res = await request(app).post('/users').send({ username: 'test', email: 'test@test.com' });
    expect(res.statusCode).toBe(200);
  });
});
 
