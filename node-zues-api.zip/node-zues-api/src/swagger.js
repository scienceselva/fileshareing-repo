const swaggerUi = require('swagger-ui-express');
const yaml = require('js-yaml');
const fs = require('fs');

function setupSwagger(app) {
  const doc = yaml.load(fs.readFileSync('./config/endpoints.yaml', 'utf8'));
  const swaggerDoc = {
    openapi: '3.0.0',
    info: { title: 'Generic YAML-driven API', version: '1.0.0' },
    paths: {}
  };

  for (const ep of doc.endpoints) {
    swaggerDoc.paths[ep.path] = {
      [ep.method.toLowerCase()]: {
        summary: ep.name,
        parameters: Object.keys(ep.input || {}).map(k => ({
          name: k,
          in: 'query',
          required: !!ep.input[k].required,
          schema: { type: ep.input[k].toLowerCase() }
        })),
        responses: { 200: { description: 'Success' } }
      }
    };
  }

  app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDoc));
}

module.exports = setupSwagger;
 
