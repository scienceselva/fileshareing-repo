const fs = require('fs');
const yaml = require('js-yaml');
const express = require('express');
const executeQuery = require('./queryExecutor');

let endpointsCache = [];

function mapOutput(row, outputMapping, processing) {
  const mapped = {};
  Object.entries(outputMapping).forEach(([key, value]) => {
    mapped[key] = row[value];
  });

  if (processing) {
    Object.entries(processing).forEach(([key, expr]) => {
      if (expr.startsWith('ADD(')) {
        const fields = expr.match(/\((.*)\)/)[1].split('+').map(f => f.trim());
        mapped[key] = fields.reduce((sum, f) => sum + Number(row[f]), 0);
      }
    });
  }

  return mapped;
}

function loadEndpoints(app) {
  const data = yaml.load(fs.readFileSync('./config/endpoints.yaml', 'utf8'));
  const endpoints = data.endpoints || [];

  // Clear old routes
  app._router.stack = app._router.stack.filter(r => !r.route);

  endpoints.forEach((ep) => {
    const { path, method, sql, input, outputfieldmapping, processing } = ep;

    app[method.toLowerCase()](path, async (req, res) => {
      try {
        const params = { ...req.body, ...req.query };

        // Validate input
        for (const [field, type] of Object.entries(input)) {
          if (!params[field] && input[field].required) {
            return res.status(400).json({ error: `Missing field: ${field}` });
          }
        }

        const rows = await executeQuery(sql, params);

        const result = rows.map(r => mapOutput(r, outputfieldmapping || {}, processing || {}));
        res.json(result);
      } catch (err) {
        res.status(500).json({ error: err.message });
      }
    });
  });

  endpointsCache = endpoints;
  console.log(`✅ Loaded ${endpoints.length} endpoints from YAML`);
}

// Watch YAML for changes
function watchConfig(app) {
  fs.watchFile('./config/endpoints.yaml', () => {
    console.log('🔁 YAML file changed. Reloading endpoints...');
    loadEndpoints(app);
  });
}

module.exports = { loadEndpoints, watchConfig };
 
