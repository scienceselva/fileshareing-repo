const express = require('express');
const bodyParser = require('body-parser');
const { loadEndpoints, watchConfig } = require('./routeLoader');
const setupSwagger = require('./swagger');

const app = express();
app.use(bodyParser.json());

// Load initial endpoints
loadEndpoints(app);

// Watch YAML for changes
watchConfig(app);

// Setup Swagger
setupSwagger(app);

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
 
