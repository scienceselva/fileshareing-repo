const pool = require('./db');

async function executeQuery(sql, params) {
  // Convert :param syntax to $1, $2 for PostgreSQL
  const keys = Object.keys(params);
  const placeholders = keys.map((_, i) => `$${i + 1}`);
  const finalSql = sql.replace(/:(\w+)/g, (_, key) => `$${keys.indexOf(key) + 1}`);
  const values = keys.map(k => params[k]);

  try {
    const res = await pool.query(finalSql, values);
    return res.rows;
  } catch (err) {
    console.error('SQL Execution Error:', err.message);
    throw new Error('Database error');
  }
}

module.exports = executeQuery;

