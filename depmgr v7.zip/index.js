const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const shell = require('shelljs');
const cors = require('cors');
const axios = require('axios');
const xml2js = require('xml2js');
const cheerio = require('cheerio');
const config = require('./config.json');

const app = express();
const PORT = 3000;
const DATA_DIR = path.join(__dirname, 'data');
const OUT_DIR = path.join(__dirname, 'out');

const GITLAB_TOKEN = config.GITLAB_TOKEN;
const GITLAB_URL = config.GITLAB_URL;

app.use(cors({
  origin: /https?:\/\/localhost(:\d+)?/,
  credentials: true
}));

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR);
}

// Ensure out directory exists
if (!fs.existsSync(OUT_DIR)) {
    fs.mkdirSync(OUT_DIR);
}

// Serve static files from 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Optional: default route to index.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.use(bodyParser.json());

// Middleware for logging
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
    next();
});

// Helper function to validate filename
const validateFilename = (filename) => {
    if (!filename || filename.includes('..') || filename.includes('/') || filename.includes('\\')) {
        return false;
    }
    return true;
};

// 1. POST endpoint to write JSON file
app.post('/api/files', (req, res) => {
    try {
        const { filename, content } = req.body;
        
        if (!filename || !content) {
            return res.status(400).json({ error: 'Filename and content are required' });
        }

        if (!validateFilename(filename)) {
            return res.status(400).json({ error: 'Invalid filename' });
        }

        const filePath = path.join(DATA_DIR, filename);
        fs.writeFileSync(filePath, JSON.stringify(content, null, 2));
        
        res.json({ message: 'File written successfully', path: filePath });
    } catch (error) {
        console.error('Error writing file:', error);
        res.status(500).json({ error: 'Failed to write file' });
    }
});

// 2. GET endpoint to read JSON file
app.get('/api/files/:filename', (req, res) => {
    try {
        const { filename } = req.params;
        
        if (!validateFilename(filename)) {
            return res.status(400).json({ error: 'Invalid filename' });
        }

        const filePath = path.join(DATA_DIR, filename);
        
        if (!fs.existsSync(filePath)) {
            return res.status(404).json({ error: 'File not found' });
        }

        const content = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
        res.json({ filename, content });
    } catch (error) {
        console.error('Error reading file:', error);
        res.status(500).json({ error: 'Failed to read file' });
    }
});

// POST execute endpoint to execute commands
app.post('/api/execute', async (req, res) => {
    try {
        const { commands, executionMode = 'sequential', filename } = req.body;
        
        // If filename is provided, read commands from file
        let commandObjects = [];
        let globalExecutionMode = executionMode;
        
        if (filename) {
            if (!validateFilename(filename)) {
                return res.status(400).json({ error: 'Invalid filename' });
            }

            const filePath = path.join(DATA_DIR, filename);
            if (!fs.existsSync(filePath)) {
                return res.status(404).json({ error: 'File not found' });
            }

            const fileContent = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
            commandObjects = normalizeCommandObjects(fileContent);
        } else {
            commandObjects = normalizeCommandObjects(commands);
        }
        
        if (!commandObjects || commandObjects.length === 0) {
            return res.status(400).json({ error: 'No valid commands found' });
        }

        // Group commands by their execution mode
        const executionGroups = [];
        let currentGroup = {
            commands: [],
            isParallel: commandObjects[0]?.isParallel ?? (globalExecutionMode === 'parallel')
        };

        for (const cmdObj of commandObjects) {
            if (cmdObj.isParallel !== currentGroup.isParallel) {
                executionGroups.push(currentGroup);
                currentGroup = {
                    commands: [],
                    isParallel: cmdObj.isParallel
                };
            }
            currentGroup.commands.push(cmdObj.command);
        }
        executionGroups.push(currentGroup);

        // Execute each group according to its mode
        const results = [];
        for (const group of executionGroups) {
            if (group.isParallel) {
                // Execute commands in parallel
                const parallelResults = await Promise.all(
                    group.commands.map(cmd => executeCommand(cmd))
                );
                results.push(...parallelResults);
            } else {
                // Execute commands sequentially
                for (const cmd of group.commands) {
                    const result = await executeCommand(cmd);
                    results.push(result);
                }
            }
        }
/*
        res.json({ 
            executionGroups: executionGroups.map(g => g.isParallel ? 'parallel' : 'sequential'),
            results 
        });
*/
        const outputPath = await writeExecutionResults(results, filename);
        const response = { 
            executionGroups: executionGroups.map(g => g.isParallel ? 'parallel' : 'sequential'),
            results,
            resultsFile: outputPath ? path.basename(outputPath) : null
        };
        res.json(response);

    } catch (error) {
        console.error('Error executing commands:', error);
        res.status(500).json({ error: 'Failed to execute commands' });
    }
});

// Helper function to execute a single command
function executeCommand(cmd) {
    return new Promise((resolve) => {
        shell.exec(cmd, { silent: false }, (code, stdout, stderr) => {
            resolve({
                command: cmd,
                exitCode: code,
                stdout: stdout,
                stderr: stderr,
                success: code === 0
            });
        });
    });
}

// Normalize different command formats into consistent objects
function normalizeCommandObjects(content) {
    if (!content) return [];
    
    // Case 1: Simple array of commands ["cmd1", "cmd2"]
    if (Array.isArray(content) && content.every(cmd => typeof cmd === 'string')) {
        return content.map(cmd => ({ command: cmd, isParallel: false }));
    }
    
    // Case 2: Array of command objects
    if (Array.isArray(content)) {
        return content.flatMap(item => {
            if (!item) return [];
            
            // Handle objects with "commands" array
            if (Array.isArray(item.commands)) {
                return item.commands.map(cmd => ({
                    command: cmd,
                    isParallel: item.isParallel || false
                }));
            }
            
            // Handle objects with "command" string
            if (typeof item.command === 'string') {
                return [{
                    command: item.command,
                    isParallel: item.isParallel || false
                }];
            }
            
            // Handle direct command strings in array
            if (typeof item === 'string') {
                return [{
                    command: item,
                    isParallel: false
                }];
            }
            
            return [];
        });
    }
    
    // Case 3: Single object with "commands" array
    if (Array.isArray(content.commands)) {
        return content.commands.map(cmd => ({
            command: cmd,
            isParallel: content.isParallel || false
        }));
    }
    
    // Case 4: Single object with "command" string
    if (typeof content.command === 'string') {
        return [{
            command: content.command,
            isParallel: content.isParallel || false
        }];
    }
    
    return [];
}


// Add this function to generate the output filename
function getOutputFilename(inputFilename) {
    if (inputFilename) {
        return `${path.parse(inputFilename).name}_results_${new Date().toISOString().replace(/[:.]/g, '-')}.txt`;
    }
    return `execution_results_${new Date().toISOString().replace(/[:.]/g, '-')}.txt`;
}

// Add this function to write results to file
async function writeExecutionResults(results, filename) {
    try {
        const outputFilename = getOutputFilename(filename);
        const outputPath = path.join(OUT_DIR, outputFilename);
        
        const resultText = results.map(r => 
            `Command: ${r.command}\n` +
            `Exit Code: ${r.exitCode}\n` +
            `Success: ${r.success}\n` +
            `Output:\n${r.stdout}\n` +
            (r.stderr ? `Errors:\n${r.stderr}\n` : '') +
            '----------------------------------------\n'
        ).join('\n');
        
        fs.writeFileSync(outputPath, resultText);
        return outputPath;
    } catch (error) {
        console.error('Error writing results file:', error);
        return null;
    }
}

// 4. NEW: GET endpoint to list all files in data directory
app.get('/api/files', (req, res) => {
    try {
        fs.readdir(DATA_DIR, (err, files) => {
            if (err) {
                console.error('Error reading directory:', err);
                return res.status(500).json({ error: 'Failed to read directory' });
            }
            
            // Filter out non-JSON files if you want only JSON files
            const jsonFiles = files.filter(file => file.endsWith('.json'));
            res.json({ files: jsonFiles });
        });
    } catch (error) {
        console.error('Error listing files:', error);
        res.status(500).json({ error: 'Failed to list files' });
    }
});

// 5. NEW: POST endpoint to execute commands from a file (by filename only)
app.post('/api/execute/file', async (req, res) => {
    try {
        const { filename, executionMode = 'sequential' } = req.body;
        
        if (!filename) {
            return res.status(400).json({ error: 'Filename is required' });
        }

        if (!validateFilename(filename)) {
            return res.status(400).json({ error: 'Invalid filename' });
        }

        const filePath = path.join(DATA_DIR, filename);
        if (!fs.existsSync(filePath)) {
            return res.status(404).json({ error: 'File not found' });
        }

        const fileContent = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
        if (!fileContent.commands || !Array.isArray(fileContent.commands)) {
            return res.status(400).json({ error: 'File must contain a "commands" array' });
        }

        let results = [];
        const commands = fileContent.commands;
        
        if (executionMode === 'parallel') {
            // Execute commands in parallel
            const executionPromises = commands.map(cmd => {
                return new Promise((resolve) => {
                    shell.exec(cmd, { silent: false }, (code, stdout, stderr) => {
                        resolve({
                            command: cmd,
                            exitCode: code,
                            stdout: stdout,
                            stderr: stderr,
                            success: code === 0
                        });
                    });
                });
            });
            
            results = await Promise.all(executionPromises);
        } else {
            // Execute commands sequentially (default)
            for (const cmd of commands) {
                const result = await new Promise((resolve) => {
                    shell.exec(cmd, { silent: false }, (code, stdout, stderr) => {
                        resolve({
                            command: cmd,
                            exitCode: code,
                            stdout: stdout,
                            stderr: stderr,
                            success: code === 0
                        });
                    });
                });
                results.push(result);
            }
        }

        res.json({ 
            executionMode,
            filename,
            results 
        });
    } catch (error) {
        console.error('Error executing commands from file:', error);
        res.status(500).json({ error: 'Failed to execute commands from file' });
    }
});

// 6. NEW: GET endpoint to download a JSON file
app.get('/api/files/download/:filename', (req, res) => {
    try {
        const { filename } = req.params;
        
        if (!validateFilename(filename)) {
            return res.status(400).json({ error: 'Invalid filename' });
        }

        const filePath = path.join(DATA_DIR, filename);
        
        if (!fs.existsSync(filePath)) {
            return res.status(404).json({ error: 'File not found' });
        }

        // Set headers for file download
        res.setHeader('Content-disposition', `attachment; filename=${filename}`);
        res.setHeader('Content-type', 'application/json');
        
        // Create read stream and pipe it to the response
        const fileStream = fs.createReadStream(filePath);
        fileStream.pipe(res);
    } catch (error) {
        console.error('Error downloading file:', error);
        res.status(500).json({ error: 'Failed to download file' });
    }
});

// GET endpoint to retrieve all files with their command data (simplified format)
app.get('/api/xfiles/all', (req, res) => {
    try {
        fs.readdir(DATA_DIR, (err, files) => {
            if (err) {
                console.error('Error reading directory:', err);
                return res.status(500).json({ error: 'Failed to read directory' });
            }

            const result = {};
            const jsonFiles = files.filter(file => file.endsWith('.json'));
            
            // Process each file sequentially
            Promise.all(jsonFiles.map(file => {
                return new Promise((resolve) => {
                    const filePath = path.join(DATA_DIR, file);
                    fs.readFile(filePath, 'utf8', (err, data) => {
                        if (!err) {
                            try {
                                const content = JSON.parse(data);
                                const fileNameWithoutExt = file.replace('.json', '');
                                
                                // Handle both formats:
                                // 1. File contains just an array ["cmd1", "cmd2"]
                                // 2. File contains object with "commands" property
                                if (Array.isArray(content)) {
                                    result[fileNameWithoutExt] = { "plan-commands": content };
                                } else if (content.commands && Array.isArray(content.commands)) {
                                    result[fileNameWithoutExt] = { "plan-commands": content.commands };
                                } else {
                                    result[fileNameWithoutExt] = { "plan-commands": [] };
                                }
                            } catch (parseError) {
                                const fileNameWithoutExt = file.replace('.json', '');
                                result[fileNameWithoutExt] = { "plan-commands": [] };
                            }
                        }
                        resolve();
                    });
                });
            })).then(() => {
                res.json(result);
            });
        });
    } catch (error) {
        console.error('Error retrieving all files:', error);
        res.status(500).json({ error: 'Failed to retrieve files' });
    }
});

// get the gitlab service pom version
app.get('/api/pomver', async (req, res) => {
    try {
        const url = req.query.gitlablink || GITLAB_URL;
        const branch = req.query.branch || GITLAB_BRANCH;
        const completeURL = url + "?branch=" + branch;
        console.log("GitLab URL:", url);

        const response = await axios.get(completeURL, {
            headers: { 'PRIVATE-TOKEN': GITLAB_TOKEN }
        });

        const parser = new xml2js.Parser();
        parser.parseString(response.data, (err, result) => {
            if (err) {
                return res.status(500).json({ error: 'Failed to parse pom.xml' });
            }
            const version = result.project.version?.[0] || 'Unknown';
            res.json({ branch, version });
        });

    } catch (error) {
        console.error('GitLab API error:', error.response?.status, error.response?.data || error.message);
        res.status(500).json({ 
            error: error.response?.data || error.message,
            status: error.response?.status
        });
    }
});


// list all jars from artifactory
app.get('/api/artifactory/list-jars', async (req, res) => {
    try {
        const repoUrl = req.query.url;
        if (!repoUrl) {
            return res.status(400).json({ error: "Missing ?url parameter" });
        }
        console.log("Artifactory URL:", repoUrl);

        // Fetch HTML listing
        const response = await axios.get(repoUrl);

        // Parse HTML and filter jar files
        const $ = cheerio.load(response.data);
        const jarFiles = [];

        $('a').each((_, el) => {
            const fileName = $(el).attr('href');
            if (fileName && fileName.endsWith('.jar')) {
                jarFiles.push(fileName);
            }
        });
        console.log("Artifactory JAR Files:", jarFiles);
        res.json({ repoUrl, jarFiles });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log(`Data directory: ${DATA_DIR}`);
});