const express = require('express');
const cors = require('cors');
const path = require('path');
const port = 3000;
const app = express();

// CORS configuration
app.use(cors({
  origin: '*', // Allow all origins
  methods: ['GET', 'POST', 'OPTIONS', 'PUT', 'DELETE'], // Allowed HTTP methods
  allowedHeaders: ['Content-Type', 'Authorization'], // Allowed headers
  credentials: false // Don't allow credentials
}));

app.use(express.static(path.join(__dirname, 'public')));

// Middleware to parse JSON bodies
app.use(express.json());


// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Something went wrong!' });
});

//app.options('*', cors(corsOptions));

app.listen(port, () => {
    console.log(`Command execution API running on http://localhost:${port}`);
});