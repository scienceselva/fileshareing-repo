package com.org.cmdrunner;
// ApiController.java
//package com.example.demo.controller;

//import com.org.cmdrunner.CommandExecutionRequest;
import com.org.cmdrunner.CommandResult;

import jakarta.annotation.PostConstruct;

import com.org.cmdrunner.CommandExecutionService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.*;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:*", allowCredentials = "true")
public class ApiController {

    private final Path dataDir;
    private final Path outDir;

    private final CommandExecutionService commandExecutionService;
    private final ObjectMapper objectMapper;

    public ApiController(@Value("${app.data-dir:data}") String dataDir,
                         @Value("${app.out-dir:out}") String outDir,
                         CommandExecutionService commandExecutionService,
                         ObjectMapper objectMapper) {
        this.dataDir = Paths.get(dataDir).toAbsolutePath().normalize();
        this.outDir = Paths.get(outDir).toAbsolutePath().normalize();
        this.commandExecutionService = commandExecutionService;
        this.objectMapper = objectMapper;
    }

    @PostConstruct
    public void init() {
        try {
            if (Files.notExists(dataDir)) {
                Files.createDirectories(dataDir);
            }
            if (Files.notExists(outDir)) {
                Files.createDirectories(outDir);
            }
        } catch (IOException e) {
            throw new RuntimeException("Could not initialize storage directories", e);
        }
    }

    private void validateFilename(String filename) {
        if (!StringUtils.hasText(filename) ||
                filename.contains("..") ||
                filename.contains("/") ||
                filename.contains("\\")) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid filename");
        }
    }

    // 1. POST /api/files : write JSON file
    @PostMapping("/files")
    public Map<String, Object> writeFile(@RequestBody Map<String, Object> request) {
        String filename = (String) request.get("filename");
        Object content = request.get("content");

        if (!StringUtils.hasText(filename) || content == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Filename and content are required");
        }
        validateFilename(filename);

        Path filePath = dataDir.resolve(filename);
        try {
            String json = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(content);
            Files.write(filePath, json.getBytes(StandardCharsets.UTF_8));
            Map<String, Object> resp = new HashMap<>();
            resp.put("message", "File written successfully");
            resp.put("path", filePath.toString());
            return resp;
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to write file", e);
        }
    }

    // 2. GET /api/files/{filename} : read JSON file
    @GetMapping("/files/{filename}")
    public Map<String, Object> readFile(@PathVariable String filename) {
        validateFilename(filename);
        Path filePath = dataDir.resolve(filename);
        if (!Files.exists(filePath)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "File not found");
        }
        try {
            String contentStr = Files.readString(filePath, StandardCharsets.UTF_8);
            Object content = objectMapper.readValue(contentStr, Object.class);
            Map<String, Object> resp = new HashMap<>();
            resp.put("filename", filename);
            resp.put("content", content);
            return resp;
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to read file", e);
        }
    }

    // 4. GET /api/files : list all JSON files in data directory
    @GetMapping("/files")
    public Map<String, Object> listFiles() {
        try {
            List<String> jsonFiles = Files.list(dataDir)
                    .filter(f -> f.getFileName().toString().endsWith(".json"))
                    .map(f -> f.getFileName().toString())
                    .collect(Collectors.toList());
            return Collections.singletonMap("files", jsonFiles);
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to list files", e);
        }
    }

    // 6. GET /api/files/download/{filename} : download JSON file
    @GetMapping("/files/download/{filename}")
    public ResponseEntity<InputStreamResource> downloadFile(@PathVariable String filename) {
        validateFilename(filename);
        Path filePath = dataDir.resolve(filename);
        if (!Files.exists(filePath)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "File not found");
        }
        try {
            InputStreamResource resource = new InputStreamResource(Files.newInputStream(filePath));
            HttpHeaders headers = new HttpHeaders();
            headers.setContentDisposition(ContentDisposition.builder("attachment").filename(filename).build());
            headers.setContentType(MediaType.APPLICATION_JSON);
            return ResponseEntity.ok()
                    .headers(headers)
                    .contentLength(Files.size(filePath))
                    .body(resource);
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to download file", e);
        }
    }

    // Helper method to normalize command objects from various formats
    private List<CommandExecutionService.CommandObject> normalizeCommandObjects(Object content) {
        return commandExecutionService.normalizeCommandObjects(content);
    }

    // 3. POST /api/execute : execute commands from body or file
    @PostMapping("/execute")
    public Map<String, Object> executeCommands(@RequestBody Map<String, Object> request) throws ExecutionException, InterruptedException {
        Object commandsObj = request.get("commands");
        String executionMode = (String) request.getOrDefault("executionMode", "sequential");
        String filename = (String) request.get("filename");

        List<CommandExecutionService.CommandObject> commandObjects;

        if (filename != null) {
            validateFilename(filename);
            Path filePath = dataDir.resolve(filename);
            if (!Files.exists(filePath)) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "File not found");
            }
            try {
                String json = Files.readString(filePath, StandardCharsets.UTF_8);
                Object fileContent = objectMapper.readValue(json, Object.class);
                commandObjects = normalizeCommandObjects(fileContent);
            } catch (IOException e) {
                throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to read command file", e);
            }
        } else {
            commandObjects = normalizeCommandObjects(commandsObj);
        }

        if (commandObjects.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No valid commands found");
        }

        // Group commands by execution mode (parallel/sequential)
        List<CommandExecutionService.ExecutionGroup> executionGroups = commandExecutionService.groupCommandsByExecutionMode(commandObjects, executionMode);

        // Execute groups accordingly
        List<CommandResult> results = commandExecutionService.executeCommandGroups(executionGroups);

        // Write results to output file
        String outputFilename = commandExecutionService.writeExecutionResults(results, filename, outDir);

        Map<String, Object> response = new HashMap<>();
        response.put("executionGroups", executionGroups.stream().map(g -> g.isParallel() ? "parallel" : "sequential").collect(Collectors.toList()));
        response.put("results", results);
        response.put("resultsFile", outputFilename != null ? outputFilename : null);
        return response;
    }

    // 5. POST /api/execute/file : execute commands from a file (filename only)
    @PostMapping("/execute/file")
    public Map<String, Object> executeCommandsFromFile(@RequestBody Map<String, Object> request) throws ExecutionException, InterruptedException {
        String filename = (String) request.get("filename");
        String executionMode = (String) request.getOrDefault("executionMode", "sequential");
        if (!StringUtils.hasText(filename)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Filename is required");
        }
        validateFilename(filename);

        Path filePath = dataDir.resolve(filename);
        if (!Files.exists(filePath)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "File not found");
        }

        try {
            String json = Files.readString(filePath, StandardCharsets.UTF_8);
            JsonNode rootNode = objectMapper.readTree(json);
            if (!rootNode.has("commands") || !rootNode.get("commands").isArray()) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "File must contain a 'commands' array");
            }
            List<String> commands = new ArrayList<>();
            rootNode.get("commands").forEach(node -> commands.add(node.asText()));

            List<CommandResult> results;
            if ("parallel".equalsIgnoreCase(executionMode)) {
                results = commandExecutionService.executeCommandsInParallel(commands);
            } else {
                results = commandExecutionService.executeCommandsSequentially(commands);
            }

            Map<String, Object> response = new HashMap<>();
            response.put("executionMode", executionMode);
            response.put("filename", filename);
            response.put("results", results);
            return response;

        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to execute commands from file", e);
        }
    }

    // 7. GET /api/xfiles/all : get all files with their command data (simplified format)
    @GetMapping("/xfiles/all")
    public Map<String, Object> getAllFilesWithCommands() {
        try {
            List<Path> jsonFiles = Files.list(dataDir)
                    .filter(f -> f.getFileName().toString().endsWith(".json"))
                    .collect(Collectors.toList());

            Map<String, Object> result = new HashMap<>();

            for (Path file : jsonFiles) {
                try {
                    String json = Files.readString(file, StandardCharsets.UTF_8);
                    JsonNode content = objectMapper.readTree(json);

                    String fileNameWithoutExt = file.getFileName().toString().replaceFirst("\\.json$", "");

                    if (content.isArray()) {
                        result.put(fileNameWithoutExt, Collections.singletonMap("plan-commands", objectMapper.convertValue(content, List.class)));
                    } else if (content.has("commands") && content.get("commands").isArray()) {
                        result.put(fileNameWithoutExt, Collections.singletonMap("plan-commands", objectMapper.convertValue(content.get("commands"), List.class)));
                    } else {
                        result.put(fileNameWithoutExt, Collections.singletonMap("plan-commands", Collections.emptyList()));
                    }

                } catch (IOException ignore) {
                    String fileNameWithoutExt = file.getFileName().toString().replaceFirst("\\.json$", "");
                    result.put(fileNameWithoutExt, Collections.singletonMap("plan-commands", Collections.emptyList()));
                }
            }

            return result;
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to retrieve files", e);
        }
    }

    // 8. GET /api/pomver : get GitLab service pom version
    // This is a simplified version; you need to configure properties for GITLAB_TOKEN and GITLAB_URL
    @Value("${gitlab.token:}")
    private String gitlabToken;

    @Value("${gitlab.url:}")
    private String gitlabUrl;

    @Value("${gitlab.branch:master}")
    private String gitlabBranch;

    @GetMapping("/pomver")
    public Map<String, Object> getPomVersion(@RequestParam(value = "gitlablink", required = false) String gitlabLink,
                                             @RequestParam(value = "branch", required = false) String branch) {
        String url = (gitlabLink != null && !gitlabLink.isBlank()) ? gitlabLink : gitlabUrl;
        String actualBranch = (branch != null && !branch.isBlank()) ? branch : gitlabBranch;

        if (url == null || url.isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "GitLab URL not configured or provided");
        }
        // Append branch query param
        String completeUrl = url + "?branch=" + actualBranch;

        try {
            // Use RestTemplate to get XML content and parse pom.xml version
            org.springframework.web.client.RestTemplate restTemplate = new org.springframework.web.client.RestTemplate();
            HttpHeaders headers = new HttpHeaders();
            if (gitlabToken != null && !gitlabToken.isBlank()) {
                headers.set("PRIVATE-TOKEN", gitlabToken);
            }
            HttpEntity<String> entity = new HttpEntity<>(headers);
            ResponseEntity<String> response = restTemplate.exchange(completeUrl, HttpMethod.GET, entity, String.class);

            String xml = response.getBody();
            if (xml == null) {
                throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Empty response from GitLab");
            }
            // Parse XML for version
            javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
            javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
            InputStream xmlStream = new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8));
            org.w3c.dom.Document doc = builder.parse(xmlStream);
            doc.getDocumentElement().normalize();

            String version = null;
            org.w3c.dom.NodeList versionNodes = doc.getElementsByTagName("version");
            if (versionNodes.getLength() > 0) {
                version = versionNodes.item(0).getTextContent();
            }
            if (version == null) {
                version = "Unknown";
            }

            Map<String, Object> resp = new HashMap<>();
            resp.put("branch", actualBranch);
            resp.put("version", version);
            return resp;

        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "GitLab API error: " + e.getMessage(), e);
        }
    }

    // 9. GET /api/artifactory/list-jars : list all jars from artifactory URL
    @GetMapping("/artifactory/list-jars")
    public Map<String, Object> listJars(@RequestParam("url") String repoUrl) {
        if (repoUrl == null || repoUrl.isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Missing ?url parameter");
        }
        try {
            org.springframework.web.client.RestTemplate restTemplate = new org.springframework.web.client.RestTemplate();
            String html = restTemplate.getForObject(repoUrl, String.class);
            if (html == null) {
                throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Empty response from repository URL");
            }
            // Parse HTML with Jsoup
            org.jsoup.nodes.Document doc = org.jsoup.Jsoup.parse(html);
            List<String> jarFiles = new ArrayList<>();
            for (org.jsoup.nodes.Element link : doc.select("a[href$=.jar]")) {
                jarFiles.add(link.attr("href"));
            }
            Map<String, Object> resp = new HashMap<>();
            resp.put("repoUrl", repoUrl);
            resp.put("jarFiles", jarFiles);
            return resp;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to list jars: " + e.getMessage(), e);
        }
    }
}

