package com.org.cmdrunner;

// CommandExecutionService.java
//package com.example.demo.service;

import com.org.cmdrunner.CommandResult;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

@Service
public class CommandExecutionService {

    public static class CommandObject {
        private final String command;
        private final boolean isParallel;

        public CommandObject(String command, boolean isParallel) {
            this.command = command;
            this.isParallel = isParallel;
        }

        public String getCommand() {
            return command;
        }

        public boolean isParallel() {
            return isParallel;
        }
    }

    public static class ExecutionGroup {
        private final List<String> commands;
        private final boolean isParallel;

        public ExecutionGroup(List<String> commands, boolean isParallel) {
            this.commands = commands;
            this.isParallel = isParallel;
        }

        public List<String> getCommands() {
            return commands;
        }

        public boolean isParallel() {
            return isParallel;
        }
    }

    // Normalize different command formats into consistent CommandObject list
    public List<CommandObject> normalizeCommandObjects(Object content) {
        if (content == null) return Collections.emptyList();

        List<CommandObject> result = new ArrayList<>();

        if (content instanceof List) {
            List<?> listContent = (List<?>) content;
            boolean allStrings = listContent.stream().allMatch(o -> o instanceof String);
            if (allStrings) {
                for (Object cmd : listContent) {
                    result.add(new CommandObject((String) cmd, false));
                }
                return result;
            }
            for (Object item : listContent) {
                if (item == null) continue;
                if (item instanceof Map) {
                    Map<?, ?> mapItem = (Map<?, ?>) item;
                    Object commandsObj = mapItem.get("commands");
                    Object commandObj = mapItem.get("command");
                    boolean isParallel = Boolean.TRUE.equals(mapItem.get("isParallel"));
                    if (commandsObj instanceof List) {
                        for (Object cmd : (List<?>) commandsObj) {
                            if (cmd instanceof String) {
                                result.add(new CommandObject((String) cmd, isParallel));
                            }
                        }
                    } else if (commandObj instanceof String) {
                        result.add(new CommandObject((String) commandObj, isParallel));
                    }
                } else if (item instanceof String) {
                    result.add(new CommandObject((String) item, false));
                }
            }
            return result;
        } else if (content instanceof Map) {
            Map<?, ?> mapContent = (Map<?, ?>) content;
            Object commandsObj = mapContent.get("commands");
            Object commandObj = mapContent.get("command");
            boolean isParallel = Boolean.TRUE.equals(mapContent.get("isParallel"));
            if (commandsObj instanceof List) {
                for (Object cmd : (List<?>) commandsObj) {
                    if (cmd instanceof String) {
                        result.add(new CommandObject((String) cmd, isParallel));
                    }
                }
                return result;
            } else if (commandObj instanceof String) {
                result.add(new CommandObject((String) commandObj, isParallel));
                return result;
            }
        }

        return Collections.emptyList();
    }

    // Group commands by their execution mode (parallel or sequential)
    public List<ExecutionGroup> groupCommandsByExecutionMode(List<CommandObject> commandObjects, String globalExecutionMode) {
        List<ExecutionGroup> groups = new ArrayList<>();
        if (commandObjects.isEmpty()) return groups;

        boolean currentIsParallel = commandObjects.get(0).isParallel();
        if (!hasMixedParallelExecution(commandObjects)) {
            currentIsParallel = "parallel".equalsIgnoreCase(globalExecutionMode);
        }

        List<String> currentGroupCommands = new ArrayList<>();

        for (CommandObject cmdObj : commandObjects) {
            if (cmdObj.isParallel() != currentIsParallel) {
                groups.add(new ExecutionGroup(currentGroupCommands, currentIsParallel));
                currentGroupCommands = new ArrayList<>();
                currentIsParallel = cmdObj.isParallel();
            }
            currentGroupCommands.add(cmdObj.getCommand());
        }
        groups.add(new ExecutionGroup(currentGroupCommands, currentIsParallel));
        return groups;
    }

    private boolean hasMixedParallelExecution(List<CommandObject> commandObjects) {
        boolean first = commandObjects.get(0).isParallel();
        for (CommandObject cmd : commandObjects) {
            if (cmd.isParallel() != first) return true;
        }
        return false;
    }

    // Execute command groups according to their mode
    public List<CommandResult> executeCommandGroups(List<ExecutionGroup> groups) throws ExecutionException, InterruptedException {
        List<CommandResult> allResults = new ArrayList<>();
        for (ExecutionGroup group : groups) {
            if (group.isParallel()) {
                allResults.addAll(executeCommandsInParallel(group.getCommands()));
            } else {
                allResults.addAll(executeCommandsSequentially(group.getCommands()));
            }
        }
        return allResults;
    }

    // Execute commands sequentially
    public List<CommandResult> executeCommandsSequentially(List<String> commands) {
        List<CommandResult> results = new ArrayList<>();
        for (String cmd : commands) {
            results.add(executeCommand(cmd));
        }
        return results;
    }

    // Execute commands in parallel
    public List<CommandResult> executeCommandsInParallel(List<String> commands) throws ExecutionException, InterruptedException {
        ExecutorService executor = Executors.newFixedThreadPool(commands.size());
        List<Future<CommandResult>> futures = new ArrayList<>();
        for (String cmd : commands) {
            futures.add(executor.submit(() -> executeCommand(cmd)));
        }
        List<CommandResult> results = new ArrayList<>();
        for (Future<CommandResult> future : futures) {
            results.add(future.get());
        }
        executor.shutdown();
        return results;
    }

    // Execute a single command, returning result
    public CommandResult executeCommand(String command) {
        ProcessBuilder builder = new ProcessBuilder();
        // Use shell to execute commands to support complex commands
        builder.command("sh", "-c", command);
        builder.redirectErrorStream(true);

        try {
            Process process = builder.start();
            StringWriter output = new StringWriter();

            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    output.write(line);
                    output.write(System.lineSeparator());
                }
            }
            int exitCode = process.waitFor();

            return new CommandResult(command, exitCode, output.toString(), "", exitCode == 0);
        } catch (IOException | InterruptedException e) {
            return new CommandResult(command, -1, "", e.getMessage(), false);
        }
    }

    // Write execution results to output file and return filename
    public String writeExecutionResults(List<CommandResult> results, String inputFilename, Path outDir) {
        String outputFilename;
        if (inputFilename != null) {
            outputFilename = inputFilename.replaceFirst("\\.json$", "") + "_results_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH-mm-ss")) + ".txt";
        } else {
            outputFilename = "execution_results_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH-mm-ss")) + ".txt";
        }

        Path outputPath = outDir.resolve(outputFilename);

        StringBuilder sb = new StringBuilder();
        for (CommandResult r : results) {
            sb.append("Command: ").append(r.getCommand()).append(System.lineSeparator());
            sb.append("Exit Code: ").append(r.getExitCode()).append(System.lineSeparator());
            sb.append("Success: ").append(r.isSuccess()).append(System.lineSeparator());
            sb.append("Output:").append(System.lineSeparator()).append(r.getStdout()).append(System.lineSeparator());
            if (r.getStderr() != null && !r.getStderr().isEmpty()) {
                sb.append("Errors:").append(System.lineSeparator()).append(r.getStderr()).append(System.lineSeparator());
            }
            sb.append("----------------------------------------").append(System.lineSeparator());
        }

        try {
            Files.writeString(outputPath, sb.toString(), StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW);
            return outputFilename;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}