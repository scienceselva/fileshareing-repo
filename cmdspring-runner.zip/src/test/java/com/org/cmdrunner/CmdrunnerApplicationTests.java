package com.org.cmdrunner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmdrunnerApplicationTests {

	@Test
	void contextLoads() {
	}

}
